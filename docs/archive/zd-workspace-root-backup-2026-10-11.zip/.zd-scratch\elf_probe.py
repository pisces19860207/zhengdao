"""只读解析 proroot 的 ELF：类型/架构/依赖/CLI 选项字符串。不动任何文件。"""
import struct, sys, os, re

def parse_elf(path):
    with open(path, 'rb') as f:
        data = f.read()
    if data[:4] != b'\x7fELF':
        return {'error': 'not ELF'}
    ei_class = data[4]  # 1=32,2=64
    ei_data = data[5]   # 1=LE,2=BE
    e_type, = struct.unpack_from('<H', data, 16)
    e_machine, = struct.unpack_from('<H', data, 18)
    e_entry, = struct.unpack_from('<Q', data, 24)
    e_phoff, = struct.unpack_from('<Q', data, 32)
    e_shoff, = struct.unpack_from('<Q', data, 40)
    e_phentsize, e_phnum = struct.unpack_from('<HH', data, 54)
    e_shentsize, e_shnum, e_shstrndx = struct.unpack_from('<HHH', data, 58)

    tmap = {0: 'NONE', 1: 'REL', 2: 'EXEC', 3: 'DYN(PIE/so)', 4: 'CORE'}
    mmap = {62: 'x86-64', 183: 'AArch64', 40: 'ARM', 3: 'x86'}

    out = {
        'file': os.path.basename(path),
        'size': len(data),
        'class': 'ELF64' if ei_class == 2 else 'ELF32',
        'endian': 'LE' if ei_data == 1 else 'BE',
        'e_type': tmap.get(e_type, str(e_type)),
        'machine': mmap.get(e_machine, str(e_machine)),
        'has_entry': e_entry != 0,
        'entry': hex(e_entry),
        'phnum': e_phnum,
    }

    # program headers -> find PT_DYNAMIC(2), PT_INTERP(3)
    interp = None
    dynoff = None
    for i in range(e_phnum):
        off = e_phoff + i * e_phentsize
        p_type, = struct.unpack_from('<I', data, off)
        p_offset, = struct.unpack_from('<Q', data, off + 8)
        p_filesz, = struct.unpack_from('<Q', data, off + 32)
        if p_type == 3:
            interp = data[p_offset:p_offset + p_filesz].rstrip(b'\x00').decode('utf-8', 'replace')
        if p_type == 2:
            dynoff, dynsz = p_offset, p_filesz

    # section headers -> locate .dynstr for DT_NEEDED names
    needed = []
    if dynoff is not None and e_shnum:
        sh = [struct.unpack_from('<IIQQQQIIQQ', data, e_shoff + i * e_shentsize)
              for i in range(e_shnum)]
        # find .dynstr
        dynstr_off = dynstr_size = None
        for s in sh:
            sh_offset, sh_size = s[4], s[5]
            if sh_offset <= dynoff < sh_offset + sh_size:
                dynstr_off, dynstr_size = sh_offset, sh_size
                break
        if dynstr_off is None:
            # fallback: any SHT_STRTAB(3) named .dynstr via shstrtab
            ssh_off, ssh_size = sh[e_shstrndx][4], sh[e_shstrndx][5]
            strtab = data[ssh_off:ssh_off + ssh_size]
            for s in sh:
                nm = strtab[s[0]:].split(b'\x00')[0].decode('utf-8', 'replace')
                if nm == '.dynstr':
                    dynstr_off, dynstr_size = s[4], s[5]
                    break
        if dynstr_off is not None:
            base = data[dynstr_off:dynstr_off + dynstr_size]
            def name_at(v):
                return base[v:].split(b'\x00')[0].decode('utf-8', 'replace')
            p = dynoff
            while p + 16 <= dynoff + dynsz:
                d_tag, = struct.unpack_from('<q', data, p)
                d_val, = struct.unpack_from('<Q', data, p + 8)
                if d_tag == 0:
                    break
                if d_tag == 1:  # DT_NEEDED
                    needed.append(name_at(d_val))
                if d_tag == 15:  # DT_RPATH
                    out['rpath'] = name_at(d_val)
                if d_tag == 29:  # DT_RUNPATH
                    out['runpath'] = name_at(d_val)
                p += 16
    out['interp'] = interp
    out['needed'] = needed
    return out


def find_cli_strings(path):
    with open(path, 'rb') as f:
        data = f.read()
    text = data.decode('latin-1')
    # 长选项风格
    longs = sorted(set(re.findall(r'--[a-zA-Z0-9][a-zA-Z0-9\-_]{2,30}', text)))
    shorts = sorted(set(re.findall(r'(?<![a-zA-Z0-9\-])-[a-zA-Z0-9](?![a-zA-Z0-9])', text)))
    envv = sorted(set(re.findall(r'PROROOT_[A-Z0-9_]+', text)))
    return longs, shorts, envv


if __name__ == '__main__':
    d = sys.argv[1] if len(sys.argv) > 1 else '.'
    for fn in sorted(os.listdir(d)):
        p = os.path.join(d, fn)
        if not os.path.isfile(p) or not fn.endswith('.so'):
            continue
        info = parse_elf(p)
        print('=' * 70)
        for k in ('file', 'size', 'class', 'endian', 'e_type', 'machine', 'has_entry', 'entry', 'interp', 'needed', 'rpath', 'runpath'):
            if k in info:
                print(f'  {k:10} = {info[k]}')
        if 'libproroot.so' == fn or fn == 'libproroot-runtime.so':
            longs, shorts, envv = find_cli_strings(p)
            print(f'  --- 长选项 (--xxx) 共 {len(longs)} ---')
            for s in longs:
                print('     ', s)
            print(f'  --- PROROOT_ 环境变量 ---')
            for s in envv:
                print('     ', s)
