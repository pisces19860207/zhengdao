#!/system/bin/sh
# 只读探针：进 proot 环境，逐条打印"真假"维度的可观测信息。不做任何写操作。
cd /data/data/com.example.zhengdao/files || exit 1
export PROOT_TMP_DIR=$PWD/proot-tmp
export PROOT_LOADER=$PWD/termux-proot/loader
export LD_LIBRARY_PATH=$PWD/termux-proot
P=$PWD/termux-proot/proot
R=$PWD/rootfs
mkdir -p "$PROOT_TMP_DIR"
echo "===== ENTER PROOT ====="
$P --link2symlink --kill-on-exit -r "$R" -0 -w /root -b /dev -b /proc -b /sys /bin/sh -c '
export PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin
export HOME=/root
export LC_ALL=C
echo "--- id ---"; id
echo "--- uname -a ---"; uname -a
echo "--- uname -r ---"; uname -r
echo "--- /proc/version ---"; cat /proc/version
echo "--- /proc/sys/kernel/osrelease ---"; cat /proc/sys/kernel/osrelease
echo "--- /proc/cpuinfo 标识行 ---"; grep -m3 -E "Hardware|model name|CPU implementer" /proc/cpuinfo 2>/dev/null || echo "(无 Hardware/model 行)"
echo "--- hostname ---"; hostname 2>&1
echo "--- /etc/hostname ---"; cat /etc/hostname 2>/dev/null || echo "(无)"
echo "--- /etc/os-release ---"; head -4 /etc/os-release 2>/dev/null
echo "--- /etc/debian_version ---"; cat /etc/debian_version 2>/dev/null || echo "(无)"
echo "--- /proc/1/comm ---"; cat /proc/1/comm 2>/dev/null
echo "--- /proc/self/cgroup ---"; head -3 /proc/self/cgroup 2>/dev/null
echo "--- /sys/fs/cgroup ---"; ls /sys/fs/cgroup 2>&1 | head -3
echo "--- systemd ---"; command -v systemctl >/dev/null 2>&1 && echo "systemctl 存在" || echo "无 systemd/init"
echo "--- systemd-detect-virt ---"; command -v systemd-detect-virt >/dev/null 2>&1 && systemd-detect-virt 2>&1 || echo "(未安装)"
echo "--- mount 尝试 ---"; mkdir -p /tmp/mnttest 2>/dev/null; mount -t tmpfs none /tmp/mnttest 2>&1 | head -2
echo "--- unshare -U ---"; unshare -U true 2>&1 || echo "unshare -U => 失败"
echo "--- /dev/kvm ---"; ls -l /dev/kvm 2>&1
echo "--- df / ---"; df -h / 2>/dev/null | tail -1
echo "--- apt-get ---"; command -v apt-get >/dev/null 2>&1 && (apt-get --version 2>/dev/null | head -1) || echo "无 apt"
echo "--- python3 / node ---"; python3 -V 2>&1; node -v 2>&1
'
echo "===== EXIT PROOT (rc=$?) ====="
