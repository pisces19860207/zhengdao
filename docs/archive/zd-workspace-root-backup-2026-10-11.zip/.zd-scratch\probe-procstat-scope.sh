#!/system/bin/sh
# 第八轮：定性 —— /proc/stat 读不到，是「安卓对所有普通 App 的限制」还是「证道自己造成的」
# 关键前提：ProotLauncher 用 -b /proc 把宿主 /proc 原样映射进去 ⇒ 里面读的就是安卓自己的文件
PROBE="/data/data/com.example.zhengdao/files/.probe-out.txt"

scan() {
  for f in stat uptime loadavg version vmstat filesystems meminfo cpuinfo diskstats swaps interrupts; do
    err=$( { head -1 /proc/$f >/dev/null; } 2>&1 )
    if [ -z "$err" ]; then printf "  %-16s READABLE\n" "/proc/$f"
    else printf "  %-16s DENIED   (%s)\n" "/proc/$f" "$err"; fi
  done
}

echo "=== 0) 当前身份 / SELinux 域 ==="
id
echo "SELinux domain = $(cat /proc/self/attr/current 2>/dev/null)"
echo

echo "=== 1) App 上下文，但不进 proot（纯安卓 untrusted_app 视角）==="
scan
echo

echo "=== 2) 同一批文件，在 proot 内（-b /proc ⇒ 同一份宿主 /proc）==="
cd /data/data/com.example.zhengdao/files || exit 1
export PROOT_TMP_DIR=$PWD/proot-tmp
export PROOT_LOADER=$PWD/termux-proot/loader
export LD_LIBRARY_PATH=$PWD/termux-proot
$PWD/termux-proot/proot --link2symlink --kill-on-exit -r "$PWD/rootfs" -0 -w /root \
  -b /dev -b /proc -b /sys /bin/bash -lc '
export PATH=/usr/bin:/bin
for f in stat uptime loadavg version vmstat filesystems meminfo cpuinfo diskstats swaps interrupts; do
  err=$( { head -1 /proc/$f >/dev/null; } 2>&1 )
  if [ -z "$err" ]; then printf "  %-16s READABLE\n" "/proc/$f"
  else printf "  %-16s DENIED   (%s)\n" "/proc/$f" "$err"; fi
done'
echo
echo "=== 3) 对照：系统里另一个真实 App（同为 untrusted_app 域）能否读 /proc/stat ==="
echo "（用 sh -c 以 shell 工具身份无法冒充，此处仅列已知事实：adb shell 域=shell，可读）"
echo "rc=$?"
