#!/system/bin/sh
# 第六轮：把「agent 实际感知到的运行时信息」全量打出来，用于判定哪些面具是真必要。
# 三态对照：A 现状 / B 仅补 procfs / C 补 procfs + 改内核号
cd /data/data/com.example.zhengdao/files || exit 1
export PROOT_TMP_DIR=$PWD/proot-tmp
export PROOT_LOADER=$PWD/termux-proot/loader
export LD_LIBRARY_PATH=$PWD/termux-proot
P=$PWD/termux-proot/proot
R=$PWD/rootfs
F=$PWD/.probe-fake
mkdir -p "$F"
{
  N=$("$P" -r "$R" -0 -b /dev -b /proc -b /sys /bin/bash -lc 'nproc 2>/dev/null' 2>/dev/null | tr -dc '0-9')
  [ -z "$N" ] && N=6
  printf 'cpu  100 0 100 10000 0 0 0 0 0 0\n'
  i=0
  while [ $i -lt $N ]; do printf 'cpu%d 12 0 12 1250 0 0 0 0 0 0\n' $i; i=$((i+1)); done
  printf 'intr 0\nctxt 0\nbtime 1699999999\nprocesses 0\nprocs_running 1\nprocs_blocked 0\nsoftirq 0\n'
} > "$F/stat"
printf '123456.78 987654.32\n' > "$F/uptime"
printf '0.50 0.60 0.70 1/500 12345\n' > "$F/loadavg"
printf 'Linux version 6.1.0-13-arm64 (debian-kernel@lists.debian.org) (gcc) #1 SMP Debian 6.1.128-1\n' > "$F/version"
printf 'zhengdao\n' > "$F/hostname"

JS='const os=require("os");
const g=(f)=>{try{return JSON.stringify(f())}catch(e){return "ERR:"+e.code}};
console.log("    cpus().length      = " + g(()=>os.cpus().length));
console.log("    availableParallelism= " + g(()=>os.availableParallelism()));
console.log("    totalmem GB        = " + g(()=>Math.round(os.totalmem()/1073741824*10)/10));
console.log("    freemem GB         = " + g(()=>Math.round(os.freemem()/1073741824*10)/10));
console.log("    loadavg            = " + g(()=>os.loadavg()));
console.log("    uptime sec         = " + g(()=>Math.round(os.uptime())));
console.log("    hostname           = " + g(()=>os.hostname()));
console.log("    release            = " + g(()=>os.release()));
console.log("    version            = " + g(()=>os.version()).slice(0,60));
console.log("    platform/arch      = " + g(()=>os.platform()+"/"+os.arch()));'

PROCS='/proc/stat /proc/loadavg /proc/uptime /proc/version /proc/meminfo /proc/cpuinfo /proc/filesystems /proc/vmstat /proc/stat'

echo "===== A) 现状（什么都不改）====="
$P --link2symlink --kill-on-exit -r "$R" -0 -w /root -b /dev -b /proc -b /sys /bin/bash -lc "
export PATH=/usr/bin:/bin
node -e '$JS' 2>&1
echo '    --- /proc 可读性 ---'
for f in $PROCS; do printf '    %-20s ' \"\$f\"; head -c 40 \"\$f\" 2>&1 | tr '\n' ' '; echo; done
echo '    --- python ---'
python3 -c 'import os;print(\"    cpu_count=%d getloadavg=%s\"%(os.cpu_count(),os.getloadavg()))' 2>&1
"

echo
echo "===== B) 仅补 procfs（内核号不动）====="
$P --link2symlink --kill-on-exit -r "$R" -0 -w /root -b /dev -b /proc -b /sys \
   -b "$F/stat:/proc/stat" -b "$F/uptime:/proc/uptime" -b "$F/loadavg:/proc/loadavg" \
   -b "$F/version:/proc/version" -b "$F/hostname:/proc/sys/kernel/hostname" /bin/bash -lc "
export PATH=/usr/bin:/bin
node -e '$JS' 2>&1
"

echo
echo "===== C) procfs + 改内核号（-k 6.1.0-13-arm64）====="
$P --link2symlink --kill-on-exit -r "$R" -0 -w /root -k 6.1.0-13-arm64 -b /dev -b /proc -b /sys \
   -b "$F/stat:/proc/stat" -b "$F/uptime:/proc/uptime" -b "$F/loadavg:/proc/loadavg" \
   -b "$F/version:/proc/version" /bin/bash -lc "
export PATH=/usr/bin:/bin
node -e '$JS' 2>&1
echo '    --- uname 全字段 ---'
uname -a
"
echo "===== rc=$? ====="
