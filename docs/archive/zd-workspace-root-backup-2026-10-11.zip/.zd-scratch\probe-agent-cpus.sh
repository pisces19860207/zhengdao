#!/system/bin/sh
# 第七轮：agent 自己有没有读 os.cpus() / availableParallelism —— 直接搜它们装好的代码。
cd /data/data/com.example.zhengdao/files || exit 1
echo "===== 搜索范围 ====="
ls -d rootfs/usr/lib/node_modules 2>/dev/null
ls -d home/.hermes 2>/dev/null
echo
echo "===== A) node_modules 里 grep os.cpus / availableParallelism ====="
timeout 90 grep -rl -e 'os\.cpus()' -e 'availableParallelism' rootfs/usr/lib/node_modules 2>/dev/null | head -20
echo "--- 命中文件数 ---"
timeout 90 grep -rl -e 'os\.cpus()' -e 'availableParallelism' rootfs/usr/lib/node_modules 2>/dev/null | wc -l
echo
echo "===== B) hermes 里 grep ====="
timeout 60 grep -rl -e 'os\.cpus()' -e 'availableParallelism' home/.hermes 2>/dev/null | head -20
echo "--- 命中文件数 ---"
timeout 60 grep -rl -e 'os\.cpus()' -e 'availableParallelism' home/.hermes 2>/dev/null | wc -l
echo
echo "===== C) 命中处上下文（前 10 条）====="
timeout 90 grep -rn -e 'os\.cpus()' -e 'availableParallelism' rootfs/usr/lib/node_modules home/.hermes 2>/dev/null | head -10
echo
echo "===== D) node_modules 顶层包 ====="
ls rootfs/usr/lib/node_modules/ 2>/dev/null | head -30
echo
echo "===== E) 三个 agent 的可执行入口 ====="
ls rootfs/usr/local/bin/ 2>/dev/null
find rootfs/usr/lib/node_modules/.bin home/.hermes -maxdepth 2 -type l 2>/dev/null | head -20
echo "rc=$?"
