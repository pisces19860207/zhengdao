#!/system/bin/sh
# 第四轮探针：agent 实际需要的「运行时信息」能不能拿到。只读。
cd /data/data/com.example.zhengdao/files || exit 1
export PROOT_TMP_DIR=$PWD/proot-tmp
export PROOT_LOADER=$PWD/termux-proot/loader
export LD_LIBRARY_PATH=$PWD/termux-proot
P=$PWD/termux-proot/proot
R=$PWD/rootfs
$P --link2symlink --kill-on-exit -r "$R" -0 -w /root -b /dev -b /proc -b /sys /bin/bash -lc '
export PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin
echo "===== 程序真正会读的 /proc 文件 ====="
for f in /proc/stat /proc/cpuinfo /proc/uptime /proc/loadavg /proc/vmstat /proc/meminfo \
         /proc/self/mountinfo /proc/mounts /proc/filesystems /proc/self/limits /proc/sys/kernel/pid_max; do
  if head -c1 "$f" >/dev/null 2>&1; then echo "OK   $f"; else echo "DENY $f"; fi
done
echo
echo "===== 能读到的部分，内容对不对 ====="
echo "nproc                  : $(nproc 2>&1)"
echo "cpuinfo processor 行数 : $(grep -c "^processor" /proc/cpuinfo 2>&1)"
echo "getconf _NPROCESSORS_ONLN : $(getconf _NPROCESSORS_ONLN 2>&1)"
echo "loadavg                : $(cat /proc/loadavg 2>&1)"
echo "meminfo MemTotal       : $(grep MemTotal /proc/meminfo 2>&1)"
echo
echo "===== Node 复验：三种取 CPU 数的方式 ====="
node -e "
const os=require(\"os\");
console.log(\"os.cpus().length        =\", os.cpus().length);
console.log(\"os.availableParallelism =\", typeof os.availableParallelism===\"function\" ? os.availableParallelism() : \"(该 Node 无此 API)\");
console.log(\"process.env.UV_THREADPOOL_SIZE =\", process.env.UV_THREADPOOL_SIZE || \"(未设)\");
console.log(\"node 版本 =\", process.version);
" 2>&1
echo
echo "===== Python 复验 ====="
python3 -c "
import os
print(\"os.cpu_count()      =\", os.cpu_count())
print(\"len(os.sched_getaffinity(0)) =\", len(os.sched_getaffinity(0)))
print(\"os.getloadavg()     =\", (lambda: os.getloadavg())() if hasattr(os,\"getloadavg\") else \"n/a\")
" 2>&1
'
echo "===== rc=$? ====="
