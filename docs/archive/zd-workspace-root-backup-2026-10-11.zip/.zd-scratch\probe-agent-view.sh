#!/system/bin/sh
# 第三轮探针：看「agent / 程序」实际会读到的平台标识。只读。
cd /data/data/com.example.zhengdao/files || exit 1
export PROOT_TMP_DIR=$PWD/proot-tmp
export PROOT_LOADER=$PWD/termux-proot/loader
export LD_LIBRARY_PATH=$PWD/termux-proot
P=$PWD/termux-proot/proot
R=$PWD/rootfs
mkdir -p "$PROOT_TMP_DIR"
$P --link2symlink --kill-on-exit -r "$R" -0 -w /root -b /dev -b /proc -b /sys /bin/bash -lc '
export PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin
export HOME=/root
echo "===== uname 全字段 ====="
echo "uname -s : $(uname -s)"
echo "uname -o : $(uname -o 2>&1)"
echo "uname -v : $(uname -v)"
echo "uname -m : $(uname -m)"
echo "uname -p : $(uname -p 2>&1)"
echo "uname -i : $(uname -i 2>&1)"
echo "uname -n : $(uname -n)"
echo "uname -r : $(uname -r)"
echo
echo "===== 可读性：/proc 下的身份文件 ====="
for f in /proc/version /proc/sys/kernel/osrelease /proc/sys/kernel/ostype /proc/sys/kernel/version /proc/uptime /proc/vmstat /proc/loadavg /proc/meminfo; do
  if head -c1 "$f" >/dev/null 2>&1; then echo "OK   $f"; else echo "DENY $f"; fi
done
echo
echo "===== Node 视角 ====="
node -e "const os=require(\"os\");console.log(\"release:\",os.release());console.log(\"version:\",os.version());console.log(\"type:\",os.type());console.log(\"platform:\",os.platform());console.log(\"arch:\",os.arch());console.log(\"cpus:\",os.cpus().length);" 2>&1
echo
echo "===== Python 视角 ====="
python3 -c "
import platform
print(\"platform.platform():\", platform.platform())
print(\"uname():\", platform.uname())
print(\"system/release/version:\", platform.system(), platform.release(), platform.version())
print(\"machine:\", platform.machine())
print(\"libc:\", platform.libc_ver())
" 2>&1
echo
echo "===== glibc / 数目 ====="
getconf GNU_LIBC_VERSION 2>&1
getconf _NPROCESSORS_ONLN 2>&1
echo
echo "===== lsb_release / os-release ====="
(command -v lsb_release >/dev/null && lsb_release -a 2>&1 | head -4) || echo "(无 lsb_release)"
grep -E "^(ID|VERSION_ID|PRETTY_NAME)=" /etc/os-release
echo
echo "===== 环境变量里有没有露 Android/Termux ====="
env | grep -i -E "android|termux|proot|prefix|com\.termux" || echo "(无)"
echo
echo "===== /proc/self/status 关键行 ====="
grep -E "^(Name|Seccomp|CapEff|Uid|Gid):" /proc/self/status 2>&1
' 2>&1
echo "===== rc=$? ====="
