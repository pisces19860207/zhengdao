# -*- coding: utf-8 -*-
"""
把「准备区」文件（男性待整理.txt）转成世界书 JSON。

安全设计：
  * 只【读取】原件，绝不修改 / 移动 / 删除。
  * 输出到 知识库/清洗版/ 下的新文件（.txt 装 JSON，与库里其它模块一致）。
  * 正文一字不改：只做「按【】分块 + 换行转义 + 套上元数据」三件事。

可逐行核对：全文没有 remove / unlink / rename / move。
"""
import json
import os

BASE   = r"C:\Users\guoli\OneDrive\Desktop\男性"
SRC    = os.path.join(BASE, "男性待整理.txt")
OUTDIR = os.path.join(BASE, "知识库", "清洗版")
OUT    = os.path.join(OUTDIR, "男性待整理-转JSON-2026-10-10.txt")


def read_lines(path):
    with open(path, "r", encoding="utf-8-sig", errors="replace") as f:
        return f.read().replace("\r\n", "\n").split("\n")


def split_blocks(lines, headers):
    """按【已知的顶层块头】切分。headers = [('【阴茎捆绑', 名), ('【母猪生殖生理', 名), ...]

    ⚠️ 不能用「所有以【开头的行」当块头 —— 正文里会出现子标题（如「【区别提醒】」），
       那样会把子标题误当成新块头，导致前一块被覆盖、内容丢失。
    """
    marks = []  # (行号, 名)
    for i, ln in enumerate(lines):
        for prefix, name in headers:
            if ln.startswith(prefix):
                marks.append((i, name))
                break
    marks.sort()

    res = {"__pre__": []}
    if not marks:
        res["__pre__"] = trim(lines)
        return res

    res["__pre__"] = trim(lines[:marks[0][0]])
    for j, (idx, name) in enumerate(marks):
        end = marks[j + 1][0] if j + 1 < len(marks) else len(lines)
        res[name] = trim(lines[idx:end])
    return res


def trim(block):
    b = list(block)
    while b and not b[0].strip():
        b.pop(0)
    while b and not b[-1].strip():
        b.pop()
    return b


def make_entry(block, group, depth, sort, key):
    return {
        "key": key,
        "value": "\n".join(block),      # 正文原样，只做换行
        "group": group,
        "key_region": 3,
        "value_region": 1,
        "sort": sort,
        "depth": depth,
        "probability": 100,
        "match_type": 2,
        "enable": True,
        "value_type": 0,
        "value_configs": [],
    }


def main():
    lines = read_lines(SRC)
    parts = split_blocks(lines, headers=[("【阴茎捆绑", "bind"), ("【母猪生殖生理", "sow")])

    pre  = parts.get("__pre__")   # 前置：微调建议（补充句，非独立模块）
    bind = parts.get("bind")      # 阴茎捆绑
    sow  = parts.get("sow")       # 母猪生殖生理（**含内部的【区别提醒】子段**）

    comment = [
        "【准备区转 JSON】源文件：男性待整理.txt —— 由 WorkBuddy 于 2026-10-10 转换（只读原件、正文一字未改）。",
        "本文件是「世界书 JSON」，扩展名沿用 .txt（与库内其它模块一致），可直接当模块加载。",
        "⚠️ 加载前请按需确认元数据：group / depth / sort / key。下列为按现有模块惯例填的默认值。",
        "① 阴茎捆绑 → **group「男性-玩法」、sort 3** —— 因为这是 `04_男性-玩法.txt` 里 **sort 3『阴茎约束、捆绑与硬质卡压真实观察』那一条的「修改版」**"
        "（源文件标题自称『**加入时间维度修改版**』，而 04 那条**没有「短时／持续几分钟」的渐进描述**）。"
        "⇒ **用途是「替换／补全那一条」，不是新增**；key 也**沿用了 04 sort3 的原 key**，方便直接换。"
        "（若你想当新增处理，请把 sort 改成 22 并换新 key，否则会与 sort3 重复触发。）",
        "② 母猪生殖生理 → **group「动物-猪类行为」、depth 5**（与 `08_母犬-发情机制.txt` 的「动物-犬类行为」**并列**；两者机制不同，不可互套）。",
        "③ 下面【颜色/温度/光泽·可选微调】是「补充句」，不是独立模块 —— 建议人工并入 `00-00-男性-生理总纲.txt` 的对应条目后再删本条；直接当模块加载会重复注入。",
    ]
    if pre:
        comment.append("—" * 20 + " 待人工并入的补充句（原文照录） " + "—" * 20)
        comment.extend("\n".join(pre).split("\n"))

    world_book = []
    if bind:
        world_book.append(make_entry(
            bind,
            group="男性-玩法",          # ← 对齐 04_男性-玩法.txt（不是新 group）
            depth=6,
            sort=3,                     # ← 对准 04 里那条 sort 3「约束、捆绑与硬质卡压」
            # key 沿用 04 sort3 的原 key，方便"原地替换"而不改变触发条件
            key="_or_捆绑@wb@捆住@wb@绳子@wb@勒住@wb@冠状沟@wb@根部@wb@孔洞@wb@卡住@wb@窄环@wb@硬环@wb@缝隙",
        ))
    if sow:
        world_book.append(make_entry(
            sow,
            group="动物-猪类行为",
            depth=5,
            sort=1,
            key="_or_母猪@wb@母畜@wb@发情周期@wb@静立反射@wb@子宫颈@wb@螺旋嵌合",
        ))

    data = {"_comment": comment, "world_book": world_book}

    os.makedirs(OUTDIR, exist_ok=True)
    with open(OUT, "w", encoding="utf-8", newline="\n") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)

    # 自检：重新读回来能否解析
    with open(OUT, "r", encoding="utf-8") as f:
        back = json.load(f)
    print("OK ->", OUT)
    print("world_book 条目数 =", len(back["world_book"]))
    for e in back["world_book"]:
        print("  ·", e["group"], "| depth", e["depth"], "| sort", e["sort"],
              "| key:", e["key"][:40] + "…", "| value 字数 ≈", len(e["value"]))
    print("_comment 行数 =", len(back["_comment"]))
    print("前置补充句是否收进 _comment =", bool(pre), "（", len(pre or []), "行 ）")

    # 完整性自检：产物（去空白）必须完整包含源文件（去空白）
    import re
    norm = lambda s: re.sub(r"\s+", "", s)
    all_text = "\n".join(back["_comment"]) + "\n" + "\n".join(e["value"] for e in back["world_book"])
    a, b = norm(open(SRC, encoding="utf-8-sig").read()), norm(all_text)
    print("源去空白 =", len(a), "| 产物去空白 =", len(b), "| 完整包含源内容 =", a in b)


if __name__ == "__main__":
    main()
