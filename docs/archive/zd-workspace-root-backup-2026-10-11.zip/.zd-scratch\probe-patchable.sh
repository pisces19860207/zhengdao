#!/system/bin/sh
# 只读探针第二轮：验证「补丁式修复」是否真的可行 + userns 能力边界。
cd /data/data/com.example.zhengdao/files || exit 1
export PROOT_TMP_DIR=$PWD/proot-tmp
export PROOT_LOADER=$PWD/termux-proot/loader
export LD_LIBRARY_PATH=$PWD/termux-proot
P=$PWD/termux-proot/proot
R=$PWD/rootfs
F=$PWD/.probe-fake
mkdir -p "$F"
printf 'Linux version 6.1.0-13-arm64 (debian-kernel@lists.debian.org) (aarch64-linux-gnu-gcc-12) #1 SMP Debian 6.1.128-1\n' > "$F/version"
printf '6.1.0-13-arm64\n' > "$F/osrelease"

echo "=== A) 现状（无 -k）==="
$P -r "$R" -0 -w /root -b /dev -b /proc -b /sys /bin/sh -c '
export PATH=/usr/bin:/bin:/usr/sbin:/sbin
uname -a; echo "hostname: $(hostname)"; echo -n "proc/version: "; cat /proc/version 2>&1'

echo
echo "=== B) 打补丁后（-k + 假文件 bind）==="
$P -r "$R" -0 -w /root -k 6.1.0-13-arm64 -b /dev -b /proc -b /sys \
   -b "$F/version:/proc/version" -b "$F/osrelease:/proc/sys/kernel/osrelease" /bin/sh -c '
export PATH=/usr/bin:/bin:/usr/sbin:/sbin
uname -a; echo "uname -r: $(uname -r)"; echo -n "proc/version: "; cat /proc/version 2>&1; echo -n "osrelease: "; cat /proc/sys/kernel/osrelease 2>&1'

echo
echo "=== C) userns 能力细查 ==="
$P -r "$R" -0 -w /root -b /dev -b /proc -b /sys /bin/sh -c '
export PATH=/usr/bin:/bin:/usr/sbin:/sbin
echo "max_user_namespaces=$(cat /proc/sys/user/max_user_namespaces 2>&1)"
echo "-- unshare -U -r id --"
unshare -U -r id 2>&1
echo "-- userns 内 mount tmpfs --"
unshare -U -r sh -c "mkdir -p /mnt/zz 2>/dev/null; mount -t tmpfs none /mnt/zz 2>&1 && (echo USERNS_MOUNT_OK; touch /mnt/zz/x && echo WRITE_OK && umount /mnt/zz && echo UMOUNT_OK) || echo USERNS_MOUNT_FAIL"
echo "-- 同时要 mount namespace --"
unshare -U -r -m sh -c "mount -t tmpfs none /mnt 2>&1 && echo MOUNT_NS_OK || echo MOUNT_NS_FAIL"
echo "-- cgroup 可写? --"
([ -w /sys/fs/cgroup ] && echo CGROUP_WRITABLE) || echo CGROUP_NOT_WRITABLE
echo "-- iptables/nft --"
command -v iptables nft 2>/dev/null || echo "(无 iptables/nft)"
'
echo "===== rc=$? ====="
