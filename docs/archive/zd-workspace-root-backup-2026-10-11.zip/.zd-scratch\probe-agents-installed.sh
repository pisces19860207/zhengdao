#!/system/bin/sh
# 第七轮 B：把「到底装了哪些 agent、它们是什么形态」查清，避免我按错对象下结论。
cd /data/data/com.example.zhengdao/files || exit 1
echo "===== 1) home 全部（含隐藏）====="
ls -a home/ 2>/dev/null
echo
echo "===== 2) home/.hermes ====="
ls -la home/.hermes/ 2>/dev/null | head -20
echo
echo "===== 3) 可能的 agent 安装位 ====="
for d in home/.local/bin home/.npm-global/bin home/.bun/bin rootfs/usr/local/bin rootfs/opt rootfs/usr/lib/node_modules; do
  printf '%-26s ' "$d"; ls "$d" 2>/dev/null | tr '\n' ' '; echo
done
echo
echo "===== 4) 全 rootfs 搜 cpus( 的 JS/二进制（限定 usr、opt、home）====="
timeout 90 grep -rl 'cpus()' rootfs/usr rootfs/opt home 2>/dev/null | head -20
echo "--- 计数 ---"
timeout 90 grep -rl 'cpus()' rootfs/usr rootfs/opt home 2>/dev/null | wc -l
echo
echo "===== 5) 有没有 claude / opencode 的入口 ====="
timeout 60 grep -rl -e 'claude' -e 'opencode' rootfs/usr/local/bin rootfs/usr/bin home/.local 2>/dev/null | head -10
ls rootfs/usr/bin 2>/dev/null | wc -l
echo "rc=$?"
