# -*- coding: utf-8 -*-
"""
合并「胯下的美食」两个分卷为一份完整版（第 1~9 章）。

安全设计（重要）：
  * 只【读取】两个原文件，绝不修改、绝不移动、绝不删除。
  * 结果写到 知识库/清洗版/ 下的【新文件】。
  * 顺带处理「同一章被论坛分段重贴、章标题重复出现」的情况：
    第二次出现的同一章标题改写为「（续）」。

可逐行核对：全文没有 remove / unlink / rename / move 之类的调用。
"""
import os
import re

BASE   = r"C:\Users\guoli\OneDrive\Desktop\男性"
TXT    = os.path.join(BASE, "TXT")
OUTDIR = os.path.join(BASE, "知识库", "清洗版")

A   = os.path.join(TXT, "原创 胯下的美食（重口味，阉割）_2.txt")   # 第 1~4 章
B   = os.path.join(TXT, "原创 胯下的美食（重口味，阉割）.txt")      # 第 5~9 章
OUT = os.path.join(OUTDIR, "原创 胯下的美食（完整版·第1-9章）.txt")

HDR = re.compile(r"^第[一二三四五六七八九十百0-9]+[章回篇]")


def read_lines(path):
    with open(path, "r", encoding="utf-8-sig", errors="replace") as f:
        return f.read().split("\n")


def drop_header(lines):
    """去掉开头的『标题行 + ===== 分隔线』两行。"""
    return lines[2:] if len(lines) >= 2 else lines


def main():
    a = read_lines(A)
    b = read_lines(B)

    out  = list(a[:2])            # 只保留一份标题 + 分隔线
    seen = set()
    dup  = 0

    for line in drop_header(a):
        s = line.strip()
        if HDR.match(s):
            if s in seen:
                out.append(s + "（续）")
                dup += 1
                continue
            seen.add(s)
        out.append(line)

    out.append("")
    out.append("==================== 以上为原『_2』（第 1~4 章）；以下为原『无后缀』（第 5~9 章） ====================")
    out.append("")

    for line in drop_header(b):
        s = line.strip()
        if HDR.match(s):
            if s in seen:
                out.append(s + "（续）")
                dup += 1
                continue
            seen.add(s)
        out.append(line)

    os.makedirs(OUTDIR, exist_ok=True)
    with open(OUT, "w", encoding="utf-8", newline="\n") as f:
        f.write("\n".join(out))

    print("OK ->", OUT)
    print("合并后行数 = %d   (原 _2 = %d 行，原无后缀 = %d 行)" % (len(out), len(a), len(b)))
    print("去重（改成『（续）』）的章标题 = %d 处" % dup)
    print("章标题一览：")
    for line in out:
        if HDR.match(line.strip()):
            print("    ", line.strip())


if __name__ == "__main__":
    main()
