#!/system/bin/sh
# 决定性命中实验：用 env -i 构造「与 ProotLauncher 完全相同的 envp」，看 guest 里有没有 Android 痕迹。
cd /data/data/com.example.zhengdao/files || exit 1
P=$PWD/termux-proot/proot
R=$PWD/rootfs
TP=$PWD/termux-proot
mkdir -p "$PWD/proot-tmp"
echo "===== 方案 1：原样启动（继承宿主 shell 环境，= 我前几轮的做法）====="
PROOT_TMP_DIR=$PWD/proot-tmp PROOT_LOADER=$TP/loader LD_LIBRARY_PATH=$TP \
"$P" --link2symlink --kill-on-exit -r "$R" -0 -w /root -b /dev -b /proc -b /sys /bin/bash -lc '
export PATH=/usr/bin:/bin
echo "  Android 痕迹条数: $(env | grep -ciE "android|apex|bootclasspath|termux")"
env | grep -iE "android|apex|bootclasspath" | cut -d= -f1 | head -8 | sed "s/^/    /"'
echo
echo "===== 方案 2：env -i，只给 ProotLauncher 那一组（= App 内 JNI 用完整 envp 的情形）====="
env -i \
  "PATH=/root/.local/bin:/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin" \
  "HOME=/root" \
  "TERM=xterm-256color" \
  "LANG=C.UTF-8" \
  "TZ=Asia/Shanghai" \
  "PROOT_TMP_DIR=$PWD/proot-tmp" \
  "UV_LINK_MODE=copy" \
  "UV_PYTHON=/usr/bin/python3" \
  "LD_LIBRARY_PATH=$TP" \
  "PROOT_LOADER=$TP/loader" \
  "$P" --link2symlink --kill-on-exit -r "$R" -0 -w /root -b /dev -b /proc -b /sys /bin/bash -lc '
export PATH=/usr/bin:/bin
echo "  Android 痕迹条数: $(env | grep -ciE "android|apex|bootclasspath|termux")"
echo "  guest 里能看到的环境变量键:"
env | cut -d= -f1 | sort | tr "\n" " " | sed "s/^/    /"
echo
echo "  --- 顺带看：这两条在两种方案下是否都成立 ---"
echo "  os.cpus().length = $(node -e "console.log(require(\"os\").cpus().length)" 2>&1)"
echo "  uname -r         = $(uname -r)"
echo "  uname -o         = $(uname -o)"'
echo "===== rc=$? ====="
