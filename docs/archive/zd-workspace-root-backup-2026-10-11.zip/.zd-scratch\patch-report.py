# -*- coding: utf-8 -*-
"""就地修正报告 md：2.5 收紧 + 附录 A/B/C 补齐（含第六/七轮实测）。"""
import io, sys

P = r"C:\Users\guoli\AndroidStudioProjects\证道设计报告\证道-集成真实虚拟机可行性报告-2026-10-09.md"
s = io.open(P, encoding="utf-8").read()
orig_len = len(s)
log = []

# ─────────────────────────────────────────────────────
# 1) 替换 §2.5 整节
# ─────────────────────────────────────────────────────
A = "### 2.5 「补面具」对里面的 Agent 到底有没有用（第三轮实测）"
B = "\n---\n\n## 3. 难点清单（按严重度排序）"
i = s.find(A); j = s.find(B, i)
assert i > 0 and j > i, "2.5 锚点未命中"

NEW25 = """### 2.5 「补面具」对里面的 Agent 到底有没有用（第三 → 第六/七轮实测，结论已收紧）

> 追问：「把第一半做了，对安装在里面的 agent 有好处吗？」
> 这一节不靠推理 —— 逐条实测。**第六、七轮又把第三轮的两条判断推翻了**，改动全部留痕在 C / G 两节与附录 C。

**结论先行（收紧后）：对这套环境里"现已装好"的 agent，2.4 那四条面具一条都没用；第三轮我推荐的"补 procfs"一组，实测后只剩 1 条值得做 —— 而且它的收益是"给以后自己装的工具兜底"，不是"修好现在的 agent"。**

**A. 2.4 那四条，逐条判定**

| 补什么 | 对 agent 有用吗 | 依据（实测） |
| --- | --- | --- |
| 提示符 PS1 | **没用** | agent 不读交互式提示符 —— 它只对人可见 |
| `/etc/hostname` | **没用**（本来就是"对的"） | 实测 `os.hostname()` = `localhost` —— 它走 `uname` 系统调用、proot 已虚拟化，**根本不读这个文件**。只有显式 `cat /etc/hostname` 才看得到打包机名 `runnervmmprz5`。⇒ 对 agent 无影响；改它是**修卫生**（构建机名不该漏进发布物），不是修功能 |
| `uname -r` 改内核号 | **没用，且有反作用** | 实测 `uname -s` = `Linux`、`-o` = `GNU/Linux`、`-m` = `aarch64`、`/etc/os-release` = `Debian 13` —— **脚本最常读的这几个本来就是对的**。改后 `os.release()` 从 `5.15.180-android13-8-…` 变成 `6.1.0-13-arm64`，但 **`os.version()` 改不动**（proot 的 `-k` 只覆盖 release 字段，它仍返回 `#1 SMP PREEMPT Tue Apr 28 14:01:49 UTC 2026`）⇒ 两个字段自相矛盾；且"报高"会让按内核版本探测特性的程序误判。**建议不做。** |
| `/proc/version` 从"读不出"变"能读" | **几乎没用**（第三轮判"有用"，第六轮**下调**） | `cat /proc/version` 现在是 `EACCES` 属实；但实测 `os.version()` **本来就返回正常值**（走 `uname` 系统调用，不经文件），没有程序靠"读 `/proc/version` 这个文件"做决策 |

**B. procfs 面具：第三轮列了 5 条，第六/七轮实测后只剩 1 条**（重要修正）

| 目标 | 第三轮判断 | 第六/七轮实测结论 |
| --- | --- | --- |
| `/proc/stat` | 补假文件，救 `os.cpus()` | **保留** —— 它是唯一真的"读不到"的，但收益见 F 节 |
| `/proc/loadavg` | 补假文件 | **撤回** —— 见 G 节：它本来就读得到值 |
| `/proc/uptime` | 补假文件 | **撤回** —— 同上 |
| `/proc/version` | 补假文件 | **撤回**（理由见 A 表末行） |
| `/proc/vmstat`、`/proc/filesystems` | 同机制，未逐个验 | 仍**未验**，维持"待核" |

> 机制在 2.4 已验证：**proot 的 `-b` 在路径解析层生效**，把假文件 bind 到 `/proc/xxx` 即可覆盖，**不需要任何内核权限**。

**C. 一条"以为成立、查代码后撤回"的（留痕）**

我一度认为**环境变量泄露**是真问题：前几轮在 `run-as` shell 内实测，guest 里能看到 `ANDROID_ROOT=/system`、`BOOTCLASSPATH=/apex/…`、`SYSTEMSERVERCLASSPATH=…` 等共 **15 条** Android 痕迹。

随后查项目自带的 JNI 源码 `app/src/main/cpp/termux/termux.c`，第 98–99 行是：

```c
clearenv();                                     // 清空父进程的全部环境
if (envp) for (; *envp; ++envp) putenv(*envp);  // 只放 ProotLauncher 给的那一组
```

⇒ **App 内启动的 proot，环境是完全重建的，Android 变量一条都进不去。** 我那个"发现"是**口径错误**（把自己的 shell 环境当成了 App 的环境），**撤回**。对照实验：用 `env -i` 复现 App 的语义后，guest 内 Android 痕迹从 15 条降到 **0 条**。

**D. 落地细节（两条，都是实测踩出来的）**

1. **假 `/proc/stat` 里写几行 `cpuN`，`os.cpus().length` 就报几** —— 它不校验，你写多少它认多少。
   实测：写 8 行 → 报 8；写 6 行 → 报 6；第六轮探针因脚本取到脏数字误写 66 行 → **Node 老老实实报了 66**。
   ⇒ 必须按**实际可用核数**生成：物理 **8** 核，但 App 被系统限制在 **6** 核（`sched_getaffinity` = 6、`nproc` = 6）。写 8 会让 Node 按 8 起 worker，而实际只有 6 核可用。
2. **假 `/proc/stat` 会让 `top` / `mpstat` 这类"读累积 CPU 时间"的工具失真**（它们算两次采样之差，而假文件里的时间是静止的）。这在 proot 里**无解** —— 真 `/proc/stat` 被 SELinux 拒、App 域读不到，属于"要么 0 核、要么假数据"的二选一。

**E. 收益量级：低（第三轮写"中低"，第六轮下调）**

调低的依据不再靠推理：**直接把已装的 agent 代码搜了一遍**（F 节）—— 实测**没有任何一处**会消费 `os.cpus().length`。

**F. 第七轮实测：现有 agent 里到底有没有地方读 `os.cpus()`？—— 没有**

在 App 私有目录里全量搜索已装 agent 的代码（`rootfs/usr`、`rootfs/opt`、`home`）：

| 命中文件 | 它怎么用 | 会不会踩到 0 |
| --- | --- | --- |
| `npm/node_modules/promise-call-limit/dist/{commonjs,esm}/index.js` | `'availableParallelism' in os ? os.availableParallelism()-1 : os.cpus().length-1` —— **带版本判断**，本机 Node 走前者 | **不会**（走不到 `cpus()` 那一支） |
| `npm/node_modules/node-gyp/lib/build.js` | 用 `os.availableParallelism()`（且只在 Windows/MSVC 分支） | 不会 |
| `rootfs/usr/bin/node` | 是**提供者**（libuv 自身实现），不是消费者 | — |
| `usr/share/bash-completion/bash_completion` | shell 补全脚本，与 CPU 数无关 | — |

而且这台机器现在装的 agent 只有 **hermes**（`home/.hermes/`，含 `installs`、`tools`、`.hermes-clone-C5D85c`）；在 `home/.hermes` 内搜索 **0 命中**。

⇒ **实测结论：当前环境里没有任何一个 agent 会消费 `os.cpus().length`。** 原因：`os.availableParallelism()`（实测 = 6，走 `sched_getaffinity`，**不读 `/proc/stat`**）在现代 Node 里已取代老 API；唯一碰老 API 的地方（npm 的 `promise-call-limit`）自带版本判断，自动走新路。

⇒ 所以补 `/proc/stat` 对**现在**这套 agent 的收益 = **0**；它的价值只在于**以后自己装的、还在用老 API 的 Node 工具**（jest、老版 webpack、pm2 等）。性质是"给未来兜底"，不是"修当前故障"。

> 口径说明：第六轮同一 API 曾读到 `availableParallelism = 7`，本轮读到 `6`。两次读数不同不影响结论（都远大于 0）。

**G. 第二轮撤回：`/proc/loadavg`、`/proc/uptime` 塞假值 —— 那是把真话换成假话**（留痕）

第六轮把"补前 / 补后"打成同环境对照，结果与我第三轮的判断**相反**：

| 项 | 现状（什么都不改） | 补假文件后 | 判定 |
| --- | --- | --- | --- |
| `os.loadavg()` | `[16.27, 16.38, 16.15]` | `[0.5, 0.6, 0.7]` | **变差** |
| `os.uptime()` | `293642` 秒 | `123457` 秒 | **变差** |
| `cat /proc/loadavg` | `Permission denied` | `0.50 0.60 0.70 1/500 12345` | 文件路"能读"了，但读出来的是假数 |

**宿主侧交叉验证**：宿主 `cat /proc/loadavg` = `16.27 16.38 16.15`，与 guest 内 `os.loadavg()` **逐位相同**；宿主 `uptime` = `293643.74`，与 guest 的 `os.uptime()` = `293642` 相同。

⇒ **真相：`os.loadavg()` / `os.uptime()` 走的是 `sysinfo()` 系统调用，不读 `/proc/*` 文件。** 所以它们**从来没坏过** —— 返回的就是这个内核的真实负载与真实开机时长（proot 与 Android 共享同一个内核，这本来就是唯一的真相）。

⇒ **第三轮那条"补 `/proc/loadavg`、`/proc/uptime`"的建议撤回。** 唯一差别只是"文件路能不能 `cat`"，**没有任何程序因此受益**，而数字从真变成了假。

**H. 总表：到底哪些"必要"**

| 项 | 对现有 agent | 对以后的工具 | 对人的眼睛 | 结论 |
| --- | --- | --- | --- | --- |
| 假 `/proc/stat` | 实测 **0** | 有（老 API 工具） | — | **唯一值得做的，但非急需** |
| 假 `/proc/loadavg`、`/proc/uptime` | **负**（造假） | 负 | — | **不做** |
| 假 `/proc/version` | 0 | 极小 | 极小 | **不做** |
| `uname -r` 改内核号 | 0 | **负**（报高误判） | 略正 | **不做** |
| `/etc/hostname` | 0 | 0 | 略正 | 可选（修卫生） |
| PS1 提示符 | 0 | 0 | **正** | 可选（给人看） |

**一句话**：这六项里，**对 agent 有用的：零项**。真正能说"值得做"的只有 `/proc/stat` 一条，理由是"给未来兜底"；另有两条（PS1、hostname）是**给人看的**。**没有一条能让跑不起来的软件跑起来。**

"""
s = s[:i] + NEW25 + s[j+1:]
log.append("§2.5 已整节替换")

# ─────────────────────────────────────────────────────
# 2) 附录 A 追加第六～七轮 + 补齐第三～五轮（md 之前漏同步）
# ─────────────────────────────────────────────────────
anc = "> 探针 A 与 B 的差别只在 proot 的启动参数，rootfs 一个字未改 ⇒ 证明「第一层（看起来像）」是**参数级**可控的，不需要动架构。"
k = s.find(anc)
assert k > 0, "附录A 锚点未命中"
ins = k + len(anc)
APP_A = """

### 第三～五轮 · agent 视角与「补 /proc」验证（2026-10-09 22:4x）

```
# ── 程序真正会读的 /proc 文件（proot 内实测）──
DENY /proc/stat          ← Node 的 os.cpus() 就读它
OK   /proc/cpuinfo
DENY /proc/uptime
DENY /proc/loadavg
DENY /proc/vmstat
OK   /proc/meminfo
OK   /proc/self/mountinfo
DENY /proc/filesystems
DENY /proc/sys/kernel/pid_max

# ── 三方视角（同一环境）──
nproc = 6            getconf _NPROCESSORS_ONLN = 8      # 物理 8 核，App 被限 6 核
node  os.cpus().length        = 0                       ← 因 /proc/stat 被拒
node  os.availableParallelism = 7                       ← 走 sched_getaffinity，正常
node  os.release()            = 5.15.180-android13-8-g1c54d617912d
python os.cpu_count()         = 8                       ← 正常
python len(sched_getaffinity) = 6
uname -s / -o / -m = Linux / GNU/Linux / aarch64        ← 本来就是对的
/etc/os-release    = Debian GNU/Linux 13 (trixie)       ← 本来就是对的

# ── 补 /proc/stat 之后（只加 -b 假文件，rootfs 未改）──
node  os.cpus().length = 8                              ← 0 → 8 ✅（假文件里写了 8 行）
node  cpus[0] = {"model":"unknown","speed":1459,"times":{...}}

# ── 环境变量：两种启动方式的对照实验 ──
继承宿主 shell（= 前几轮探针的口径）：Android 痕迹 15 条
env -i 只给 ProotLauncher 那一组：Android 痕迹 0 条
```

> App 侧决定性证据（项目自带 JNI 源码 `app/src/main/cpp/termux/termux.c`）：`:98 clearenv();`　`:99 if (envp) for (; *envp; ++envp) putenv(*envp);`　`:108 execvp(cmd, argv);` ⇒ App 内启动的 proot，环境是**完全重建**的 ⇒ 「环境变量泄露」不成立，见 2.5-C。

### 第六～七轮 · 三态对照 + agent 消费点搜索（2026-10-09 22:5x）

```
# ── 三态对照：node 的运行时感知面（同一 rootfs，只改 proot 启动参数）──
                          A) 现状             B) 只补 procfs     C) 补 procfs + 改内核号
os.cpus().length          0                   6                  6
os.cpus().length - 1      -1                  5                  5
os.availableParallelism   6                   6                  6
os.totalmem() GB          10.9                10.9               10.9
os.freemem() GB           2.3                 2.3                2.3
os.loadavg()              [16.27,16.38,16.15] [0.5,0.6,0.7]      [0.5,0.6,0.7]
os.uptime() 秒            293642              123457             123457
os.hostname()             "localhost"         "localhost"        "localhost"
os.release()              5.15.180-android13-8-g1c54d617912d      6.1.0-13-arm64
os.version()              #1 SMP PREEMPT Tue Apr 28 14:01:49 UTC 2026（三态都不变）
os.platform()/arch()      linux/arm64         linux/arm64        linux/arm64

# ── 文件路可读性 ──
/proc/stat        DENY → 假   /proc/loadavg  DENY → 假   /proc/uptime  DENY → 假
/proc/version     DENY → 假   /proc/meminfo  OK          /proc/cpuinfo OK
/etc/hostname     runnervmmprz5（未改）
/etc/os-release   Debian GNU/Linux 13 (trixie)   ← 本来就是对的

# ── 宿主侧交叉验证（证明 loadavg / uptime 来自 sysinfo 系统调用）──
宿主 /proc/loadavg = 16.27 16.38 16.15     ← 与 guest os.loadavg() 逐位相同
宿主 /proc/uptime  = 293643.74             ← 与 guest os.uptime() = 293642 相同
宿主 nproc         = 6

# ── "照抄"实测（第六轮探针自带的坑）──
假 stat 写 8 行 cpuN  → os.cpus().length = 8
假 stat 写 6 行 cpuN  → os.cpus().length = 6
假 stat 写 66 行 cpuN → os.cpus().length = 66     ← 脚本取到脏数字，Node 照抄

# ── 第七轮：现有 agent 里谁在消费 os.cpus() / availableParallelism ──
搜索范围  rootfs/usr  rootfs/opt  home      （全量）
命中：npm/node_modules/promise-call-limit/dist/{commonjs,esm}/index.js
        └ 'availableParallelism' in os ? os.availableParallelism()-1 : os.cpus().length-1
      npm/node_modules/node-gyp/lib/build.js     （用 availableParallelism，且仅 Windows 分支）
      rootfs/usr/bin/node                         （提供者，非消费者）
      usr/share/bash-completion/bash_completion   （无关）
home/.hermes 内命中数 = 0
已装 agent = 仅 hermes（home/.hermes/{installs,tools,.hermes-clone-C5D85c}）
```
"""
s = s[:ins] + APP_A + s[ins:]
log.append("附录A 已补第三～七轮")

# ─────────────────────────────────────────────────────
# 3) 附录 B 补行
# ─────────────────────────────────────────────────────
ancB = "| `unshare -U` 能建 user namespace，但其中 `mount` 仍被拒"
kb = s.find(ancB)
assert kb > 0, "附录B 锚点未命中"
endB = s.find("\n", kb)
ROWS_B = """
| `os.cpus().length` = 0 的成因；补后值 = 你写几行 `cpuN` 就报几（不校验） | ★★★ | 本机三态对照（附录 A 第六轮，可复现） |
| `os.loadavg()` / `os.uptime()` 走 `sysinfo()` 系统调用、**不读 `/proc/*`** ⇒ 从来没坏过 | ★★★ | 本机对照：guest 值与宿主 `/proc/loadavg`、`/proc/uptime` 逐位相同（附录 A 第六轮） |
| App 传给 proot 的环境经 `clearenv()` 完全重建，Android 变量零进入 | ★★★ | 项目源码 `app/src/main/cpp/termux/termux.c:98`（源代码级证据） |
| 现有已装 agent **无一处**消费 `os.cpus().length`（唯一命中带版本判断，走 `availableParallelism`） | ★★★ | 本机全量搜索已装 agent 代码（附录 A 第七轮） |"""
s = s[:endB] + ROWS_B + s[endB:]
log.append("附录B 已补 4 行")

# ─────────────────────────────────────────────────────
# 4) 附录 C 补行 7/8/9
# ─────────────────────────────────────────────────────
ancC = "| 6 | 我一度以为"
kc = s.find(ancC)
assert kc > 0, "附录C 锚点未命中"
endC = s.find("\n", kc)
ROWS_C = """
| 7 | 我一度把「环境变量泄露 Android 标识」当成真问题（实测到 15 条 `ANDROID_*`） | 那是**探针口径错误**：`run-as` 启动的 shell 自己带着 adb 的环境。查项目 JNI 源码确认 `termux.c:98` 是 `clearenv()` + 只 `putenv(envp)` ⇒ **App 内环境完全重建，Android 变量一条都进不去**。已用 `env -i` 对照复现（15 条 → 0 条）。**该条结论撤回**，只在 2.5-C 留痕 |
| 8 | 「补 `/proc/loadavg`、`/proc/uptime` 对 agent 有用」→ **撤回** | 第六轮三态对照推翻：这两个值**本来就读得到**（走 `sysinfo()` 系统调用，返回宿主真实数据；guest 值与宿主 `/proc/loadavg`、`/proc/uptime` 逐位相同）。塞假文件**不是修复，是把真话换成假话**。见 2.5-G |
| 9 | 「补 `/proc/stat` 对 agent 有用」→ 下调为「**对现有 agent 收益 0，只对未来工具兜底**」 | 第七轮把已装 agent 的代码全搜了一遍：**无一处**消费 `os.cpus().length`（唯一命中带版本判断，自动走 `availableParallelism`）。也下调了「`/proc/version` 有用」到「几乎没用」（`os.version()` 本来就正常，不经文件）。见 2.5-A/E/F |"""
s = s[:endC] + ROWS_C + s[endC:]
log.append("附录C 已补 3 行")

io.open(P, "w", encoding="utf-8", newline="").write(s)
print("\n".join(log))
print("长度: %d -> %d" % (orig_len, len(s)))
