#!/system/bin/sh
# 第六轮 B：核数写对（6），并验证「文件路 vs 系统调用路」两条通道的差别。
cd /data/data/com.example.zhengdao/files || exit 1
export PROOT_TMP_DIR=$PWD/proot-tmp
export PROOT_LOADER=$PWD/termux-proot/loader
export LD_LIBRARY_PATH=$PWD/termux-proot
P=$PWD/termux-proot/proot
R=$PWD/rootfs
F=$PWD/.probe-fake
mkdir -p "$F"
N=6
{
  printf 'cpu  100 0 100 10000 0 0 0 0 0 0\n'
  i=0
  while [ $i -lt $N ]; do printf 'cpu%d 12 0 12 1250 0 0 0 0 0 0\n' $i; i=$((i+1)); done
  printf 'intr 0\nctxt 0\nbtime 1699999999\nprocesses 0\nprocs_running 1\nprocs_blocked 0\nsoftirq 0\n'
} > "$F/stat"
printf '123456.78 987654.32\n' > "$F/uptime"
printf '0.50 0.60 0.70 1/500 12345\n' > "$F/loadavg"
printf 'Linux version 6.1.0-13-arm64 (debian-kernel@lists.debian.org) #1 SMP Debian 6.1.128-1\n' > "$F/version"

JS='const os=require("os");
const g=(f)=>{try{return JSON.stringify(f())}catch(e){return "ERR:"+e.code}};
console.log("    cpus().length       = " + g(()=>os.cpus().length));
console.log("    availableParallelism= " + g(()=>os.availableParallelism()));
console.log("    loadavg             = " + g(()=>os.loadavg()));
console.log("    uptime sec          = " + g(()=>Math.round(os.uptime())));
console.log("    hostname            = " + g(()=>os.hostname()));
console.log("    release             = " + g(()=>os.release()));
console.log("    cpus().length - 1   = " + (os.cpus().length-1));'

echo "===== A) 现状：文件路逐条实测 ====="
$P --link2symlink --kill-on-exit -r "$R" -0 -w /root -b /dev -b /proc -b /sys /bin/bash -lc "
export PATH=/usr/bin:/bin
node -e '$JS' 2>&1
echo '    --- 文件路 ---'
for f in /proc/stat /proc/loadavg /proc/uptime /proc/version /etc/hostname; do printf '    %-18s ' \"\$f\"; cat \"\$f\" 2>&1 | head -1 | cut -c1-50; done
echo '    --- 文件路之外：/etc/os-release ---'
head -2 /etc/os-release
"

echo
echo "===== B) 补 procfs（核数=6，内核号不动）====="
$P --link2symlink --kill-on-exit -r "$R" -0 -w /root -b /dev -b /proc -b /sys \
   -b "$F/stat:/proc/stat" -b "$F/uptime:/proc/uptime" -b "$F/loadavg:/proc/loadavg" -b "$F/version:/proc/version" \
   /bin/bash -lc "
export PATH=/usr/bin:/bin
node -e '$JS' 2>&1
echo '    --- 文件路 ---'
for f in /proc/stat /proc/loadavg /proc/uptime /proc/version; do printf '    %-18s ' \"\$f\"; cat \"\$f\" 2>&1 | head -1 | cut -c1-50; done
echo '    --- nproc / python ---'
nproc
python3 -c 'import os;print(\"cpu_count=%d\"%os.cpu_count())'
"
echo "===== rc=$? ====="
