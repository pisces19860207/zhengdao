# -*- coding: utf-8 -*-
"""第八轮：把「哪些是这类 App 的通病、哪些不是」写进报告（md / html 双份）。"""
import io, sys

MD = r"C:\Users\guoli\AndroidStudioProjects\证道设计报告\证道-集成真实虚拟机可行性报告-2026-10-09.md"
HT = r"C:\Users\guoli\AndroidStudioProjects\证道设计报告\证道-集成真实虚拟机可行性报告-2026-10-09.html"

# ──────────────────────────────────────────── Markdown ──────────────────────
md_sec = u"""### 2.6 收口：这些「不真」，哪些是这类 App 的通病，哪些不是（第八轮实测）

一句话：**「缺自己的内核」和「缺硬件加速」是同类 App 共有的天花板；「`/proc` 统计被封」是安卓给全体第三方 App 立的规矩；而同类 App 常见的那几个坑，证道一件都没犯。**

#### A. 真·同一个天花板（任何 proot / chroot 方案都躲不掉）

| 现象 | 根源 | 为什么躲不掉 |
|---|---|---|
| `mount` 被拒、`/sys/fs/cgroup` 不可写、真 init 缺席 | proot 是**系统调用翻译**，借的是安卓自己的内核 | 要让 Linux 拿到一块自己的内核，只有虚拟机或 root |
| systemd / docker 一概不可用 | 同上 + 没有 PID 1 | 同上 |
| 本机 KVM / AVF 全断，真 VM 只能软件模拟（慢 5–20×） | 设备 ROM 未开放虚拟化，SoC 侧也拿不到节点 | 这条甚至**不分 App** —— 换 Termux 来也是一样 |

#### B. 不是某个 App 的锅 —— 是安卓对全体第三方 App 的统一收口

第八轮在 **App 身份（不进 proot）** 下逐文件实测：

```text
/proc/stat        DENIED      ← 标签 u:object_r:proc_stat:s0
/proc/uptime      DENIED      ← 标签 u:object_r:proc_uptime:s0
/proc/loadavg     DENIED      ← 标签 u:object_r:proc_loadavg:s0
/proc/version     DENIED      ← 标签 u:object_r:proc_version:s0
/proc/vmstat      DENIED
/proc/filesystems DENIED
/proc/diskstats   DENIED
/proc/swaps       DENIED
/proc/interrupts  DENIED
/proc/meminfo     READABLE    ← 标签 u:object_r:proc_meminfo:s0
/proc/cpuinfo     READABLE    ← 标签 u:object_r:proc_cpuinfo:s0
```

三点：

1. 这些标签名（`proc_stat` / `proc_uptime` / `proc_loadavg` / `proc_version`）是 **AOSP 自己定义的标准类型**，不是荣耀加的私规 ⇒ 这是**谷歌给全安卓立的规矩**。
2. `run-as` 落到的是 `runas_app` 域，**不是** App 实际运行的 `untrusted_app`。已查证 AOSP `private/runas_app.te` 首行是 `untrusted_app_domain(runas_app)` ⇒ **继承 untrusted_app 同套规则**（另加 ptrace / perf 等调试特权）⇒ 上面这组 DENIED **反映的就是真实 App 的能力边界**，不是我的测量假象。
3. **换个 App 也照样中招**：Termux 在 **Android 10** 上 `import psutil` 直接崩于 `PermissionError: [Errno 13] Permission denied: '/proc/stat'`，报单人自己归因为 *"SeLinux restrictions on Android"*（psutil issue #2195）。⇒ **不同 App、不同安卓版本、同一堵墙。**

#### C. 反过来说：同类 App 常见的几个坑，证道一件都没犯

| 常见坑 | 证道实测 |
|---|---|
| Linux 环境里混进 `ANDROID_ROOT` 等安卓变量 | **没有** —— JNI 层 `clearenv()` 完全重建环境 |
| `uname -s/-o/-m`、`/etc/os-release` 不像 Linux | **本来就是正确的 Debian 13** |
| `hostname` 是一串随机机器名 | **本来就是 `localhost`** |
| loadavg / uptime 拿不到 | **文件确实读不到，但 agent 拿到的是对的** —— libuv 走 `sysinfo()` 系统调用，与 `/proc` 无关；实测量值与宿主逐位相同 |

最后一行值得单拎出来说：它是「看着像坏了、其实没坏」的典型 —— **文件读不到 ≠ 数据拿不到**。

#### D. 口径收在哪里

- 证道「不真」的那部分 ＝ **同类方案的公共边界**，不是它的实现缺陷。
- 唯一能在安卓内部彻底跨过去的办法 ＝ **虚拟机**；本机硬件加速全断 ⇒ 只能软件模拟 ⇒ 慢一个数量级 ⇒ 不建议（见第 1 / 3 节）。
- 想要「真内核 + 不慢」＝ 只能把机器放到设备之外（项目设计文档 §10 已预留的云机 / 瘦客户端）。

---

"""

md_appB = [
    (u"| "
     u"`/proc/stat` `/proc/uptime` `/proc/loadavg` `/proc/version` 在 App 身份下全部 DENIED；`meminfo` `cpuinfo` 仍可读 | ★★★ | 本机 adb 第八轮（`ls -Z` 取到 AOSP 标准标签 `proc_stat` 等）+ Termux/Android 10 交叉印证（psutil #2195） |"),
    (u"| `run-as` 落到 `runas_app` 域而非 `untrusted_app`，但前者经 `untrusted_app_domain()` 宏继承同套规则 ⇒ 测量口径有效 | ★★☆ | AOSP 源码 `platform/system/sepolicy` `private/runas_app.te` 首行（源代码级） |"),
]

md_appC = [
    (u"| 10 | 「`/proc/loadavg`、`/proc/uptime` 实测可读」→ **这句是错的**（口径错误） | 第八轮在 App 身份下（含 proot 内）逐文件实测：这两个文件**同样 DENIED**。我当初看到的是「绑了假文件之后 `cat` 通了」，把它误记成「原本可读」。**结论（不该补）不变，且理由更强**：文件确实读不到，而 Node 返回的量值仍与宿主**逐位相同** ⇒ 硬证据证明 libuv 走 `sysinfo()`，与 `/proc` 完全无关。见 2.5-G / 2.6-C |"),
    (u"| 11 | 测量口径自查：`run-as` 用的 SELinux 域是 `runas_app`，**不是** App 真实的 `untrusted_app` | 曾担心前几轮全部 DENIED 结论因此失效。查 AOSP `private/runas_app.te` 首行 `untrusted_app_domain(runas_app)` ⇒ **继承 untrusted_app 同套规则**（另加调试特权）⇒ **前几轮测量有效，无需撤回**。此条作为口径说明登记，不计为错误 |"),
]

md_row8_old = u"| 8 | 「补 `/proc/loadavg`、`/proc/uptime` 对 agent 有用」→ **撤回** | 第六轮三态对照推翻：这两个值**本来就读得到**（走 `sysinfo()` 系统调用，返回宿主真实数据；guest 值与宿主 `/proc/loadavg`、`/proc/uptime` 逐位相同）。塞假文件**不是修复，是把真话换成假话**。见 2.5-G |"
md_row8_new = u"| 8 | 「补 `/proc/loadavg`、`/proc/uptime` 对 agent 有用」→ **撤回** | 第六轮三态对照推翻。⚠️ 当时的措辞「本来就读得到」已由第八轮更正：**作为文件它们同样 DENIED**，但 Node 拿到的仍是宿主真值 ⇒ 走的是 `sysinfo()` 系统调用、不经 `/proc`。塞假文件**不是修复，是把真话换成假话**。见 2.5-G 与留痕第 10 条 |"


def patch_md():
    s = io.open(MD, encoding=u"utf-8").read()
    anc = u"## 3. 难点清单（按严重度排序）"
    i = s.find(anc)
    assert i > 0, u"md 锚点(第3节)未命中"
    if u"2.6 收口" in s:
        print(u"  md: §2.6 已存在，跳过插入")
    else:
        s = s[:i] + md_sec + s[i:]
        print(u"  md: §2.6 已插入")

    # 附录 B：插到表格最后一行数据之后（锚点用末行，避免被格式化工具合并的行干扰）
    anc_b = u"| 现有已装 agent **无一处**消费 `os.cpus().length`"
    j = s.find(anc_b)
    assert j > 0, u"md 附录B 锚点未命中"
    # 找到该行末尾（表格内不会有空行）
    k = s.find(u"\n", j)
    add = u"\n" + u"\n".join(md_appB)
    hit = False
    if u"App 身份下全部 DENIED" not in s:
        s = s[:k] + add + s[k:]
        hit = True
    print(u"  md: 附录B 追加 %s" % (u"完成" if hit else u"已存在"))

    # 附录 C：更正第 8 条 + 追加 10/11
    if md_row8_old in s:
        s = s.replace(md_row8_old, md_row8_new)
        print(u"  md: 第 8 条已更正")
    else:
        print(u"  md: 第 8 条原句未逐字命中（可能已被格式化），跳过更正")
    addc = u"\n" + u"\n".join(md_appC)
    if u"| 10 | 「`/proc/loadavg`" not in s:
        # 插到附录 C 表格最后一行（第 9 条）之后，不能插到文末（文末是页脚）
        p = s.find(u"| 9 | \u300c\u8865 `/proc/stat`")
        if p < 0:
            p = s.rfind(u"\n| 9 | ")
        assert p > 0, u"md 附录C 第9条锚点未命中"
        q = s.find(u"\n", p)
        s = s[:q] + addc + s[q:]
        print(u"  md: 附录C 追加 10/11 条")
    else:
        print(u"  md: 附录C 10/11 已存在")
    io.open(MD, u"w", encoding=u"utf-8", newline=u"").write(s)


# ──────────────────────────────────────────── HTML ─────────────────────────
def build_html_sec(wrap_pre, wrap_close):
    def pre(t):
        return wrap_pre + t + wrap_close
    return u"""<h3>2.6 收口：这些「不真」，哪些是这类 App 的通病，哪些不是（第八轮实测）</h3>

<div class="callout">
  <p>一句话：<b>「缺自己的内核」和「缺硬件加速」是同类 App 共有的天花板；「<code>/proc</code> 统计被封」是安卓给全体第三方 App 立的规矩；而同类 App 常见的那几个坑，证道一件都没犯。</b></p>
</div>

<h4>A. 真·同一个天花板（任何 proot / chroot 方案都躲不掉）</h4>

<div class="tw">
  <table>
    <thead>
      <tr><th>现象</th><th>根源</th><th>为什么躲不掉</th></tr>
    </thead>
    <tbody>
      <tr><td><code>mount</code> 被拒、<code>/sys/fs/cgroup</code> 不可写、真 init 缺席</td><td>proot 是<b>系统调用翻译</b>，借的是安卓自己的内核</td><td>要让 Linux 拿到一块自己的内核，只有虚拟机或 root</td></tr>
      <tr><td>systemd / docker 一概不可用</td><td>同上 + 没有 PID 1</td><td>同上</td></tr>
      <tr><td>本机 KVM / AVF 全断，真 VM 只能软件模拟（慢 5–20×）</td><td>设备 ROM 未开放虚拟化，SoC 侧也拿不到节点</td><td>这条甚至<b>不分 App</b> —— 换 Termux 来也是一样</td></tr>
    </tbody>
  </table>
</div>

<h4>B. 不是某个 App 的锅 —— 是安卓对全体第三方 App 的统一收口</h4>

<p>第八轮在 <b>App 身份（不进 proot）</b> 下逐文件实测：</p>

""" + pre(u"""<code>/proc/stat        DENIED      ← 标签 u:object_r:proc_stat:s0
/proc/uptime      DENIED      ← 标签 u:object_r:proc_uptime:s0
/proc/loadavg     DENIED      ← 标签 u:object_r:proc_loadavg:s0
/proc/version     DENIED      ← 标签 u:object_r:proc_version:s0
/proc/vmstat      DENIED
/proc/filesystems DENIED
/proc/diskstats   DENIED
/proc/swaps       DENIED
/proc/interrupts  DENIED
/proc/meminfo     READABLE    ← 标签 u:object_r:proc_meminfo:s0
/proc/cpuinfo     READABLE    ← 标签 u:object_r:proc_cpuinfo:s0</code>""") + u"""

<p>三点：</p>
<ol>
  <li>这些标签名（<code>proc_stat</code> / <code>proc_uptime</code> / <code>proc_loadavg</code> / <code>proc_version</code>）是 <b>AOSP 自己定义的标准类型</b>，不是荣耀加的私规 ⇒ 这是<b>谷歌给全安卓立的规矩</b>。</li>
  <li><code>run-as</code> 落到的是 <code>runas_app</code> 域，<b>不是</b> App 实际运行的 <code>untrusted_app</code>。已查证 AOSP <code>private/runas_app.te</code> 首行是 <code>untrusted_app_domain(runas_app)</code> ⇒ <b>继承 untrusted_app 同套规则</b>（另加 ptrace / perf 等调试特权）⇒ 上面这组 DENIED <b>反映的就是真实 App 的能力边界</b>，不是我的测量假象。</li>
  <li><b>换个 App 也照样中招</b>：Termux 在 <b>Android 10</b> 上 <code>import psutil</code> 直接崩于 <code>PermissionError: [Errno 13] Permission denied: '/proc/stat'</code>，报单人自己归因为 <i>"SeLinux restrictions on Android"</i>（psutil issue #2195）。⇒ <b>不同 App、不同安卓版本、同一堵墙。</b></li>
</ol>

<h4>C. 反过来说：同类 App 常见的几个坑，证道一件都没犯</h4>

<div class="tw">
  <table>
    <thead>
      <tr><th>常见坑</th><th>证道实测</th></tr>
    </thead>
    <tbody>
      <tr><td>Linux 环境里混进 <code>ANDROID_ROOT</code> 等安卓变量</td><td><b>没有</b> —— JNI 层 <code>clearenv()</code> 完全重建环境</td></tr>
      <tr><td><code>uname -s/-o/-m</code>、<code>/etc/os-release</code> 不像 Linux</td><td><b>本来就是正确的 Debian 13</b></td></tr>
      <tr><td><code>hostname</code> 是一串随机机器名</td><td><b>本来就是 <code>localhost</code></b></td></tr>
      <tr><td>loadavg / uptime 拿不到</td><td><b>文件确实读不到，但 agent 拿到的是对的</b> —— libuv 走 <code>sysinfo()</code> 系统调用，与 <code>/proc</code> 无关；实测量值与宿主逐位相同</td></tr>
    </tbody>
  </table>
</div>

<p class="note">最后一行值得单拎出来说：它是「看着像坏了、其实没坏」的典型 —— <b>文件读不到 ≠ 数据拿不到</b>。</p>

<h4>D. 口径收在哪里</h4>

<ul>
  <li>证道「不真」的那部分 ＝ <b>同类方案的公共边界</b>，不是它的实现缺陷。</li>
  <li>唯一能在安卓内部彻底跨过去的办法 ＝ <b>虚拟机</b>；本机硬件加速全断 ⇒ 只能软件模拟 ⇒ 慢一个数量级 ⇒ 不建议（见第 1 / 3 节）。</li>
  <li>想要「真内核 + 不慢」＝ 只能把机器放到设备之外（项目设计文档 §10 已预留的云机 / 瘦客户端）。</li>
</ul>

"""


def patch_html():
    s = io.open(HT, encoding=u"utf-8").read()
    if u"<pre><code>" in s:
        wp, wc = u"<pre><code>", u"</code></pre>"
    else:
        wp, wc = u"<pre>", u"</pre>"
    print(u"  html: 代码块样式 = %s" % wp)
    anc = u"<h2>3. 难点清单</h2>"
    i = s.find(anc)
    assert i > 0, u"html 锚点未命中"
    if u"2.6 收口" not in s:
        s = s[:i] + build_html_sec(wp, wc) + s[i:]
        print(u"  html: §2.6 已插入")
    else:
        print(u"  html: §2.6 已存在，跳过")

    anc_b = u"允许第三方 App 拿到虚拟机的先例（Podroid，设备支持 + 一次 adb 授权）"
    rows = [
        u'    <tr><td><code>/proc/stat</code> <code>/proc/uptime</code> <code>/proc/loadavg</code> <code>/proc/version</code> 在 App 身份下全部 DENIED；<code>meminfo</code> <code>cpuinfo</code> 仍可读</td><td><span class="ev ev3">★★★</span></td><td>本机 adb 第八轮（<code>ls -Z</code> 取到 AOSP 标准标签 <code>proc_stat</code> 等）+ Termux/Android 10 交叉印证（psutil #2195）</td></tr>',
        u'    <tr><td><code>run-as</code> 落到 <code>runas_app</code> 域而非 <code>untrusted_app</code>，但前者经 <code>untrusted_app_domain()</code> 宏继承同套规则 ⇒ 测量口径有效</td><td><span class="ev ev2">★★☆</span></td><td>AOSP 源码 <code>platform/system/sepolicy</code> <code>private/runas_app.te</code> 首行（源代码级）</td></tr>',
    ]
    j = s.find(anc_b)
    if j > 0:
        k = s.find(u"\n", j)
        s = s[:k+1] + u"\n".join(rows) + s[k:]
        print(u"  html: 附录B 追加 2 行")
    else:
        print(u"  html: 附录B 锚点未命中")

    # 更正第 8 条
    old8 = u"第六轮三态对照推翻：这两个值<b>本来就读得到</b>"
    new8 = u"第六轮三态对照推翻。⚠️ 当时措辞「本来就读得到」已由第八轮更正：<b>作为文件它们同样 DENIED</b>，但 Node 拿到的仍是宿主真值 ⇒ 走的是 <code>sysinfo()</code> 系统调用、不经 <code>/proc</code>"
    if old8 in s:
        s = s.replace(old8, new8)
        print(u"  html: 第 8 条已更正")
    else:
        print(u"  html: 第 8 条原文未命中")

    # 追加留痕 10/11
    rowsC = [
        u'    <tr><td>10</td><td>「<code>/proc/loadavg</code>、<code>/proc/uptime</code> 实测可读」→ <b>这句是错的</b>（口径错误）</td><td>第八轮在 App 身份下（含 proot 内）逐文件实测：这两个文件<b>同样 DENIED</b>。我当初看到的是「绑了假文件之后 <code>cat</code> 通了」，把它误记成「原本可读」。<b>结论（不该补）不变，且理由更强</b>：文件确实读不到，而 Node 返回的量值仍与宿主<b>逐位相同</b> ⇒ 硬证据证明 libuv 走 <code>sysinfo()</code>，与 <code>/proc</code> 完全无关。见 2.5-G / 2.6-C</td></tr>',
        u'    <tr><td>11</td><td>测量口径自查：<code>run-as</code> 用的 SELinux 域是 <code>runas_app</code>，<b>不是</b> App 真实的 <code>untrusted_app</code></td><td>曾担心前几轮全部 DENIED 结论因此失效。查 AOSP <code>private/runas_app.te</code> 首行 <code>untrusted_app_domain(runas_app)</code> ⇒ <b>继承 untrusted_app 同套规则</b>（另加调试特权）⇒ <b>前几轮测量有效，无需撤回</b>。此条作为口径说明登记，不计为错误</td></tr>',
    ]
    anc_c = u"</tbody>"
    j = s.rfind(anc_c)
    if j > 0 and u"<td>10</td>" not in s:
        s = s[:j] + u"\n".join(rowsC) + u"\n" + s[j:]
        print(u"  html: 附录C 追加 10/11 条")
    else:
        print(u"  html: 附录C 追加跳过（已存在或锚点异常）")
    io.open(HT, u"w", encoding=u"utf-8", newline=u"").write(s)


patch_md()
patch_html()
print(u"完成")
