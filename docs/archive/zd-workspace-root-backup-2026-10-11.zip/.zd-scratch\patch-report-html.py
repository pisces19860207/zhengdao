# -*- coding: utf-8 -*-
"""就地修正报告 html：2.5 收紧 + §0 补一句 + 附录 A/B/C 补齐（与 md 同步）。"""
import io

P = r"C:\Users\guoli\AndroidStudioProjects\证道设计报告\证道-集成真实虚拟机可行性报告-2026-10-09.html"
s = io.open(P, encoding="utf-8").read()
orig = len(s)
log = []

# ── 1) §2.5 整节替换 ────────────────────────────────
A = '<h3>2.5 「补面具」对里面的 Agent 到底有没有用</h3>'
B = '<h2>3. 难点清单</h2>'
i = s.find(A); j = s.find(B, i)
assert i > 0 and j > i, "2.5 锚点未命中"

NEW25 = '''<h3>2.5 「补面具」对里面的 Agent 到底有没有用（第三 → 第六/七轮实测，结论已收紧）</h3>

<p class="note">追问：<b>「把第一半做了，对安装在里面的 agent 有好处吗？」</b> 这一节不靠推理 —— 逐条实测。<b>第六、七轮又把第三轮的两条判断推翻了</b>，改动全部留痕在 C / G 两节与附录 C。</p>

<div class="callout warn">
  <p><b>结论先行（收紧后）</b>：对这套环境里<b>现已装好</b>的 agent，2.4 那四条面具<b>一条都没用</b>；第三轮我推荐的「补 procfs」一组，实测后<b>只剩 1 条值得做</b> —— 而且它的收益是「给以后自己装的工具兜底」，<b>不是</b>「修好现在的 agent」。</p>
</div>

<h4>A. 2.4 那四条，逐条判定</h4>

<div class="tw">
<table>
  <thead><tr><th>补什么</th><th>对 agent 有用吗</th><th>依据（实测）</th></tr></thead>
  <tbody>
    <tr><td>提示符 PS1</td><td><b>没用</b></td><td>agent 不读交互式提示符 —— 它只对人可见</td></tr>
    <tr><td><code>/etc/hostname</code></td><td><b>没用</b>（本来就是「对的」）</td><td>实测 <code>os.hostname()</code> = <code>localhost</code> —— 它走 <code>uname</code> 系统调用、proot 已虚拟化，<b>根本不读这个文件</b>。只有显式 <code>cat /etc/hostname</code> 才看得到打包机名 <code>runnervmmprz5</code>。⇒ 对 agent 无影响；改它是<b>修卫生</b>（构建机名不该漏进发布物），不是修功能</td></tr>
    <tr><td><code>uname -r</code> 改内核号</td><td><b>没用，且有反作用</b></td><td>实测 <code>uname -s</code> = <code>Linux</code>、<code>-o</code> = <code>GNU/Linux</code>、<code>-m</code> = <code>aarch64</code>、<code>/etc/os-release</code> = <code>Debian 13</code> —— <b>脚本最常读的这几个本来就是对的</b>。改后 <code>os.release()</code> 从 <code>5.15.180-android13-8-…</code> 变成 <code>6.1.0-13-arm64</code>，但 <b><code>os.version()</code> 改不动</b>（proot 的 <code>-k</code> 只覆盖 release 字段，它仍返回 <code>#1 SMP PREEMPT Tue Apr 28 14:01:49 UTC 2026</code>）⇒ 两个字段自相矛盾；且「报高」会让按内核版本探测特性的程序误判。<b>建议不做。</b></td></tr>
    <tr><td><code>/proc/version</code> 从「读不出」变「能读」</td><td><b>几乎没用</b>（第三轮判「有用」，第六轮<b>下调</b>）</td><td><code>cat /proc/version</code> 现在是 <code>EACCES</code> 属实；但实测 <code>os.version()</code> <b>本来就返回正常值</b>（走 <code>uname</code> 系统调用，不经文件），没有程序靠「读 <code>/proc/version</code> 这个文件」做决策</td></tr>
  </tbody>
</table>
</div>

<h4>B. procfs 面具：第三轮列了 5 条，第六/七轮实测后只剩 1 条（重要修正）</h4>

<div class="tw">
<table>
  <thead><tr><th>目标</th><th>第三轮判断</th><th>第六/七轮实测结论</th></tr></thead>
  <tbody>
    <tr><td><code>/proc/stat</code></td><td>补假文件，救 <code>os.cpus()</code></td><td><b>保留</b> —— 它是唯一真的「读不到」的，但收益见 F 节</td></tr>
    <tr><td><code>/proc/loadavg</code></td><td>补假文件</td><td><b>撤回</b> —— 见 G 节：它本来就读得到值</td></tr>
    <tr><td><code>/proc/uptime</code></td><td>补假文件</td><td><b>撤回</b> —— 同上</td></tr>
    <tr><td><code>/proc/version</code></td><td>补假文件</td><td><b>撤回</b>（理由见 A 表末行）</td></tr>
    <tr><td><code>/proc/vmstat</code>、<code>/proc/filesystems</code></td><td>同机制，未逐个验</td><td>仍<b>未验</b>，维持「待核」</td></tr>
  </tbody>
</table>
</div>

<p class="note">机制在 2.4 已验证：<b>proot 的 <code>-b</code> 在路径解析层生效</b>，把假文件 bind 到 <code>/proc/xxx</code> 即可覆盖，<b>不需要任何内核权限</b>。</p>

<h4>C. 一条「以为成立、查代码后撤回」的（留痕）</h4>

<div class="callout warn">
  <p>我一度认为<b>环境变量泄露</b>是真问题：前几轮在 <code>run-as</code> shell 内实测，guest 里能看到 <code>ANDROID_ROOT=/system</code>、<code>BOOTCLASSPATH=/apex/…</code>、<code>SYSTEMSERVERCLASSPATH=…</code> 等共 <b>15 条</b> Android 痕迹。</p>
  <p>随后查项目自带的 JNI 源码 <code>app/src/main/cpp/termux/termux.c</code>，第 98–99 行是：</p>
</div>

<pre><code>clearenv();                                     // 清空父进程的全部环境
if (envp) for (; *envp; ++envp) putenv(*envp);  // 只放 ProotLauncher 给的那一组</code></pre>

<div class="callout warn">
  <p>⇒ <b>App 内启动的 proot，环境是完全重建的，Android 变量一条都进不去。</b>我那个「发现」是<b>口径错误</b>（把自己的 shell 环境当成了 App 的环境），<b>撤回</b>。</p>
  <p class="note">对照实验：用 <code>env -i</code> 复现 App 的语义后，guest 内 Android 痕迹从 15 条降到 <b>0 条</b>。</p>
</div>

<h4>D. 落地细节（两条，都是实测踩出来的）</h4>

<div class="callout">
  <p><b>① 假 <code>/proc/stat</code> 里写几行 <code>cpuN</code>，<code>os.cpus().length</code> 就报几</b> —— 它不校验，你写多少它认多少。</p>
  <p>实测：写 8 行 → 报 8；写 6 行 → 报 6；第六轮探针因脚本取到脏数字误写 66 行 → <b>Node 老老实实报了 66</b>。</p>
  <p>⇒ 必须按<b>实际可用核数</b>生成：物理 <b>8</b> 核，但 App 被系统限制在 <b>6</b> 核（<code>sched_getaffinity</code> = 6、<code>nproc</code> = 6）。写 8 会让 Node 按 8 起 worker，而实际只有 6 核可用。</p>
  <p><b>② 假 <code>/proc/stat</code> 会让 <code>top</code> / <code>mpstat</code> 这类「读累积 CPU 时间」的工具失真</b>（它们算两次采样之差，而假文件里的时间是静止的）。这在 proot 里<b>无解</b> —— 真 <code>/proc/stat</code> 被 SELinux 拒、App 域读不到，属于「要么 0 核、要么假数据」的二选一。</p>
</div>

<h4>E. 收益量级：低（第三轮写「中低」，第六轮下调）</h4>

<div class="callout good">
  <p>调低的依据不再靠推理：<b>直接把已装的 agent 代码搜了一遍</b>（F 节）—— 实测<b>没有任何一处</b>会消费 <code>os.cpus().length</code>。</p>
</div>

<h4>F. 第七轮实测：现有 agent 里到底有没有地方读 <code>os.cpus()</code>？—— 没有</h4>

<p class="note">在 App 私有目录里全量搜索已装 agent 的代码（<code>rootfs/usr</code>、<code>rootfs/opt</code>、<code>home</code>）：</p>

<div class="tw">
<table>
  <thead><tr><th>命中文件</th><th>它怎么用</th><th>会不会踩到 0</th></tr></thead>
  <tbody>
    <tr><td><code>npm/node_modules/promise-call-limit/dist/{commonjs,esm}/index.js</code></td><td><code>'availableParallelism' in os ? os.availableParallelism()-1 : os.cpus().length-1</code> —— <b>带版本判断</b>，本机 Node 走前者</td><td><b>不会</b>（走不到 <code>cpus()</code> 那一支）</td></tr>
    <tr><td><code>npm/node_modules/node-gyp/lib/build.js</code></td><td>用 <code>os.availableParallelism()</code>（且只在 Windows/MSVC 分支）</td><td>不会</td></tr>
    <tr><td><code>rootfs/usr/bin/node</code></td><td>是<b>提供者</b>（libuv 自身实现），不是消费者</td><td>—</td></tr>
    <tr><td><code>usr/share/bash-completion/bash_completion</code></td><td>shell 补全脚本，与 CPU 数无关</td><td>—</td></tr>
  </tbody>
</table>
</div>

<div class="callout warn">
  <p>而且这台机器现在装的 agent 只有 <b>hermes</b>（<code>home/.hermes/</code>，含 <code>installs</code>、<code>tools</code>、<code>.hermes-clone-C5D85c</code>）；在 <code>home/.hermes</code> 内搜索 <b>0 命中</b>。</p>
  <p>⇒ <b>实测结论：当前环境里没有任何一个 agent 会消费 <code>os.cpus().length</code>。</b>原因：<code>os.availableParallelism()</code>（实测 = 6，走 <code>sched_getaffinity</code>，<b>不读 <code>/proc/stat</code></b>）在现代 Node 里已取代老 API；唯一碰老 API 的地方（npm 的 <code>promise-call-limit</code>）自带版本判断，自动走新路。</p>
</div>

<div class="callout good">
  <p>⇒ 所以补 <code>/proc/stat</code> 对<b>现在</b>这套 agent 的收益 = <b>0</b>；它的价值只在于<b>以后自己装的、还在用老 API 的 Node 工具</b>（jest、老版 webpack、pm2 等）。性质是「给未来兜底」，不是「修当前故障」。</p>
  <p class="note">口径说明：第六轮同一 API 曾读到 <code>availableParallelism = 7</code>，本轮读到 <code>6</code>。两次读数不同不影响结论（都远大于 0）。</p>
</div>

<h4>G. 第二轮撤回：<code>/proc/loadavg</code>、<code>/proc/uptime</code> 塞假值 —— 那是把真话换成假话（留痕）</h4>

<p class="note">第六轮把「补前 / 补后」打成同环境对照，结果与我第三轮的判断<b>相反</b>：</p>

<div class="tw">
<table>
  <thead><tr><th>项</th><th>现状（什么都不改）</th><th>补假文件后</th><th>判定</th></tr></thead>
  <tbody>
    <tr><td><code>os.loadavg()</code></td><td><code>[16.27, 16.38, 16.15]</code></td><td><code>[0.5, 0.6, 0.7]</code></td><td><b>变差</b></td></tr>
    <tr><td><code>os.uptime()</code></td><td><code>293642</code> 秒</td><td><code>123457</code> 秒</td><td><b>变差</b></td></tr>
    <tr><td><code>cat /proc/loadavg</code></td><td><code>Permission denied</code></td><td><code>0.50 0.60 0.70 1/500 12345</code></td><td>文件路「能读」了，但读出来的是假数</td></tr>
  </tbody>
</table>
</div>

<div class="callout warn">
  <p><b>宿主侧交叉验证</b>：宿主 <code>cat /proc/loadavg</code> = <code>16.27 16.38 16.15</code>，与 guest 内 <code>os.loadavg()</code> <b>逐位相同</b>；宿主 <code>uptime</code> = <code>293643.74</code>，与 guest 的 <code>os.uptime()</code> = <code>293642</code> 相同。</p>
  <p>⇒ <b>真相：<code>os.loadavg()</code> / <code>os.uptime()</code> 走的是 <code>sysinfo()</code> 系统调用，不读 <code>/proc/*</code> 文件。</b>所以它们<b>从来没坏过</b> —— 返回的就是这个内核的真实负载与真实开机时长（proot 与 Android 共享同一个内核，这本来就是唯一的真相）。</p>
  <p>⇒ <b>第三轮那条「补 <code>/proc/loadavg</code>、<code>/proc/uptime</code>」的建议撤回。</b>唯一差别只是「文件路能不能 <code>cat</code>」，<b>没有任何程序因此受益</b>，而数字从真变成了假。</p>
</div>

<h4>H. 总表：到底哪些「必要」</h4>

<div class="tw">
<table>
  <thead><tr><th>项</th><th>对现有 agent</th><th>对以后的工具</th><th>对人的眼睛</th><th>结论</th></tr></thead>
  <tbody>
    <tr><td>假 <code>/proc/stat</code></td><td>实测 <b>0</b></td><td>有（老 API 工具）</td><td>—</td><td><b>唯一值得做的，但非急需</b></td></tr>
    <tr><td>假 <code>/proc/loadavg</code>、<code>/proc/uptime</code></td><td><b>负</b>（造假）</td><td>负</td><td>—</td><td><b>不做</b></td></tr>
    <tr><td>假 <code>/proc/version</code></td><td>0</td><td>极小</td><td>极小</td><td><b>不做</b></td></tr>
    <tr><td><code>uname -r</code> 改内核号</td><td>0</td><td><b>负</b>（报高误判）</td><td>略正</td><td><b>不做</b></td></tr>
    <tr><td><code>/etc/hostname</code></td><td>0</td><td>0</td><td>略正</td><td>可选（修卫生）</td></tr>
    <tr><td>PS1 提示符</td><td>0</td><td>0</td><td><b>正</b></td><td>可选（给人看）</td></tr>
  </tbody>
</table>
</div>

<div class="callout warn">
  <p><b>一句话</b>：这六项里，<b>对 agent 有用的：零项</b>。真正能说「值得做」的只有 <code>/proc/stat</code> 一条，理由是「给未来兜底」；另有两条（PS1、hostname）是<b>给人看的</b>。<b>没有一条能让跑不起来的软件跑起来。</b></p>
</div>

'''
s = s[:i] + NEW25 + s[j:]
log.append("§2.5 已整节替换")

# ── 2) §0 补一句 ──────────────────────────────────
anc0 = '详见 2.4。</p>\n</div>'
k = s.find(anc0)
assert k > 0, "§0 锚点未命中"
k += len(anc0)
NEW0 = '''

<div class="callout warn">
  <p><b>再补一句（第六/七轮实测后新增）</b>：如果你问的是 <b>「补了那些面具，对里面的 agent 有没有好处」</b> —— 实测答案是 <b>「对现在装好的 agent，零好处」</b>。原本列的四条（内核号 / <code>/proc/version</code> / 主机名 / 提示符）<b>没有一条被 agent 消费</b>；我上一轮推荐的 <code>procfs</code> 一组，实测后<b>只剩 <code>/proc/stat</code> 一条值得做</b>，而它在现有 agent 里也<b>找不到消费点</b>（唯一命中处走的是 <code>availableParallelism()</code>，本来就正常）。另有两条撤回：塞假 <code>/proc/loadavg</code>、<code>/proc/uptime</code> 是<b>把真数据换成假数据</b>。<b>全部细节见 2.5。</b></p>
</div>'''
s = s[:k] + NEW0 + s[k:]
log.append("§0 已补一句")

# ── 3) 附录 A 追加第六～七轮 ────────────────────────
ancA = '<h2>附录 B · 证据等级与外部来源</h2>'
ka = s.find(ancA)
assert ka > 0, "附录A 锚点未命中"
APP_A = '''<h3>第六～七轮 · 三态对照 + agent 消费点搜索（2026-10-09 22:5x）</h3>

<pre><code># ── 三态对照：node 的运行时感知面（同一 rootfs，只改 proot 启动参数）──
                          A) 现状             B) 只补 procfs     C) 补 procfs + 改内核号
os.cpus().length          0                   6                  6
os.cpus().length - 1      -1                  5                  5
os.availableParallelism   6                   6                  6
os.totalmem() GB          10.9                10.9               10.9
os.freemem() GB           2.3                 2.3                2.3
os.loadavg()              [16.27,16.38,16.15] [0.5,0.6,0.7]      [0.5,0.6,0.7]
os.uptime() 秒            293642              123457             123457
os.hostname()             "localhost"         "localhost"        "localhost"
os.release()              5.15.180-android13-8-g1c54d617912d      6.1.0-13-arm64
os.version()              #1 SMP PREEMPT Tue Apr 28 14:01:49 UTC 2026（三态都不变）
os.platform()/arch()      linux/arm64         linux/arm64        linux/arm64

# ── 文件路可读性 ──
/proc/stat        DENY → 假   /proc/loadavg  DENY → 假   /proc/uptime  DENY → 假
/proc/version     DENY → 假   /proc/meminfo  OK          /proc/cpuinfo OK
/etc/hostname     runnervmmprz5（未改）
/etc/os-release   Debian GNU/Linux 13 (trixie)   ← 本来就是对的

# ── 宿主侧交叉验证（证明 loadavg / uptime 来自 sysinfo 系统调用）──
宿主 /proc/loadavg = 16.27 16.38 16.15     ← 与 guest os.loadavg() 逐位相同
宿主 /proc/uptime  = 293643.74             ← 与 guest os.uptime() = 293642 相同
宿主 nproc         = 6

# ── "照抄"实测（第六轮探针自带的坑）──
假 stat 写 8 行 cpuN  → os.cpus().length = 8
假 stat 写 6 行 cpuN  → os.cpus().length = 6
假 stat 写 66 行 cpuN → os.cpus().length = 66     ← 脚本取到脏数字，Node 照抄

# ── 第七轮：现有 agent 里谁在消费 os.cpus() / availableParallelism ──
搜索范围  rootfs/usr  rootfs/opt  home      （全量）
命中：npm/node_modules/promise-call-limit/dist/{commonjs,esm}/index.js
        └ 'availableParallelism' in os ? os.availableParallelism()-1 : os.cpus().length-1
      npm/node_modules/node-gyp/lib/build.js     （用 availableParallelism，且仅 Windows 分支）
      rootfs/usr/bin/node                         （提供者，非消费者）
      usr/share/bash-completion/bash_completion   （无关）
home/.hermes 内命中数 = 0
已装 agent = 仅 hermes（home/.hermes/{installs,tools,.hermes-clone-C5D85c}）</code></pre>

'''
s = s[:ka] + APP_A + s[ka:]
log.append("附录A 已补第六～七轮")

# ── 4) 附录 B 补 4 行 ─────────────────────────────
ancB = '<tr><td><code>unshare -U</code> 能建 user namespace，但其中 <code>mount</code> 仍被拒</td>'
kb = s.find(ancB)
assert kb > 0, "附录B 锚点未命中"
endB = s.find("\n", kb)
ROWS_B = '''
    <tr><td><code>os.cpus().length</code> = 0 的成因；补后值 = 你写几行 <code>cpuN</code> 就报几（不校验）</td><td><span class="ev ev3">★★★</span></td><td>本机三态对照（附录 A 第六轮，可复现）</td></tr>
    <tr><td><code>os.loadavg()</code> / <code>os.uptime()</code> 走 <code>sysinfo()</code> 系统调用、<b>不读 <code>/proc/*</code></b> ⇒ 从来没坏过</td><td><span class="ev ev3">★★★</span></td><td>本机对照：guest 值与宿主 <code>/proc/loadavg</code>、<code>/proc/uptime</code> 逐位相同（附录 A 第六轮）</td></tr>
    <tr><td>App 传给 proot 的环境经 <code>clearenv()</code> 完全重建，Android 变量零进入</td><td><span class="ev ev3">★★★</span></td><td>项目源码 <code>app/src/main/cpp/termux/termux.c:98</code>（源代码级证据）</td></tr>
    <tr><td>现有已装 agent <b>无一处</b>消费 <code>os.cpus().length</code>（唯一命中带版本判断，走 <code>availableParallelism</code>）</td><td><span class="ev ev3">★★★</span></td><td>本机全量搜索已装 agent 代码（附录 A 第七轮）</td></tr>'''
s = s[:endB] + ROWS_B + s[endB:]
log.append("附录B 已补 4 行")

# ── 5) 附录 C 补 8/9 行 ───────────────────────────
ancC = '<tr><td>7</td>'
kc = s.find(ancC)
assert kc > 0, "附录C 锚点未命中"
endC = s.find("\n", kc)
ROWS_C = '''
    <tr><td>8</td><td>「补 <code>/proc/loadavg</code>、<code>/proc/uptime</code> 对 agent 有用」→ <b>撤回</b></td><td>第六轮三态对照推翻：这两个值<b>本来就读得到</b>（走 <code>sysinfo()</code> 系统调用，返回宿主真实数据；guest 值与宿主 <code>/proc/loadavg</code>、<code>/proc/uptime</code> 逐位相同）。塞假文件<b>不是修复，是把真话换成假话</b>。见 2.5-G</td></tr>
    <tr><td>9</td><td>「补 <code>/proc/stat</code> 对 agent 有用」→ 下调为「<b>对现有 agent 收益 0，只对未来工具兜底</b>」</td><td>第七轮把已装 agent 的代码全搜了一遍：<b>无一处</b>消费 <code>os.cpus().length</code>（唯一命中带版本判断，自动走 <code>availableParallelism</code>）。也把「<code>/proc/version</code> 有用」下调到「几乎没用」（<code>os.version()</code> 本来就正常，不经文件）。见 2.5-A/E/F</td></tr>'''
s = s[:endC] + ROWS_C + s[endC:]
log.append("附录C 已补 8/9 行")

io.open(P, "w", encoding="utf-8", newline="").write(s)
print("\n".join(log))
print("长度: %d -> %d" % (orig, len(s)))
