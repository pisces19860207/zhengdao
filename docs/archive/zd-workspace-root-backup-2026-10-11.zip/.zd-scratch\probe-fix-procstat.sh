#!/system/bin/sh
# 第五轮：验证「补 /proc 能否救回 agent 的运行时感知」。会写一个假 /proc/stat 到 App 私有目录（只读环境内不生效，仅本次实验）。
cd /data/data/com.example.zhengdao/files || exit 1
export PROOT_TMP_DIR=$PWD/proot-tmp
export PROOT_LOADER=$PWD/termux-proot/loader
export LD_LIBRARY_PATH=$PWD/termux-proot
P=$PWD/termux-proot/proot
R=$PWD/rootfs
F=$PWD/.probe-fake
mkdir -p "$F"
{
  printf 'cpu  100 0 100 10000 0 0 0 0 0 0\n'
  i=0
  while [ $i -lt 8 ]; do printf 'cpu%d 12 0 12 1250 0 0 0 0 0 0\n' $i; i=$((i+1)); done
  printf 'intr 0\nctxt 0\nbtime 1699999999\nprocesses 0\nprocs_running 1\nprocs_blocked 0\nsoftirq 0\n'
} > "$F/stat"
printf '123456.78 987654.32\n' > "$F/uptime"
printf '0.50 0.60 0.70 1/500 12345\n' > "$F/loadavg"
printf '/dev/root / ext4 rw 0 0\n' > "$F/filesystems"

echo "===== A) 补之前（现状）====="
$P --link2symlink --kill-on-exit -r "$R" -0 -w /root -b /dev -b /proc -b /sys /bin/bash -lc '
export PATH=/usr/bin:/bin
node -e "const os=require(\"os\");console.log(\"  os.cpus().length =\", os.cpus().length)" 2>&1
echo "  cat /proc/stat  -> $(cat /proc/stat 2>&1 | head -1)"
echo "  cat /proc/loadavg -> $(cat /proc/loadavg 2>&1)"'

echo
echo "===== B) 补之后（-k + bind 假 /proc/stat、uptime、loadavg）====="
$P --link2symlink --kill-on-exit -r "$R" -0 -w /root -k 6.1.0-13-arm64 -b /dev -b /proc -b /sys \
   -b "$F/stat:/proc/stat" -b "$F/uptime:/proc/uptime" -b "$F/loadavg:/proc/loadavg" /bin/bash -lc '
export PATH=/usr/bin:/bin
node -e "const os=require(\"os\");const c=os.cpus();console.log(\"  os.cpus().length =\", c.length);console.log(\"  cpus[0] =\", JSON.stringify(c[0]));console.log(\"  availableParallelism =\", os.availableParallelism())" 2>&1
echo "  cat /proc/stat  -> $(cat /proc/stat 2>&1 | head -2 | tr \"\n\" \"|\")"
echo "  cat /proc/loadavg -> $(cat /proc/loadavg 2>&1)"
echo "  cat /proc/uptime  -> $(cat /proc/uptime 2>&1)"
echo "  python cpu_count  -> $(python3 -c "import os;print(os.cpu_count())" 2>&1)"'
echo "===== rc=$? ====="
